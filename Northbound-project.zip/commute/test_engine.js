'use strict';
const assert = require('node:assert/strict');
const E = require('./static/engine.js');
const D = require('./data/timetable.json');
const W = require('./data/walking.json');
let count=0;
function test(name, fn) { fn(); console.log('✓',name); count++; }
const ref = (d,t) => E.wallEpoch(d,t);
const planned = (d,t,dir='toBN',extra={}) => E.allRows(D,{reference:ref(d,t),direction:dir,mode:'plan',horizon:120,...extra});

test('Brussels summer and winter time do not depend on browser timezone',()=>{
 assert.equal(ref('2026-09-07','08:00'),Date.parse('2026-09-07T06:00:00Z')/1000);
 assert.equal(ref('2026-12-01','08:00'),Date.parse('2026-12-01T07:00:00Z')/1000);
 assert.equal(E.hhmm(ref('2026-09-07','08:00')),'08:00');
});
test('First morning shuttle TNT returns are 05:38, 05:48',()=>{
 const r=E.shuttleRows(ref('2026-09-07','05:00'),'toBN',45);
 assert.deepEqual(r.map(x=>E.hhmm(x.departure)),['05:38']);
 const r2=E.shuttleRows(ref('2026-09-07','05:00'),'toBN',60);
 assert.deepEqual(r2.map(x=>E.hhmm(x.departure)),['05:38','05:48','05:58']);
 assert.equal(r2[0].quality,'derived'); assert.equal(r2[0].ride,480);
});
test('BN morning departures are not incorrectly shifted',()=>{
 assert.deepEqual(E.shuttleRows(ref('2026-09-07','05:00'),'toTNT',55).map(x=>E.hhmm(x.departure)),['05:30','05:40','05:50']);
});
test('Peak departures use the user-assumed grid anchored at 07:00',()=>{
 const r=E.shuttleRows(ref('2026-09-07','07:00'),'toTNT',150);
 assert.deepEqual(r.map(x=>E.hhmm(x.departure)),E.MORNING_PEAK);
 assert.deepEqual(r.slice(0,4).map(x=>E.hhmm(x.departure)),['07:00','07:08','07:16','07:24']);
 assert.equal(r[0].quality,'scheduled'); // 07:00 also appears explicitly in the PDF.
 assert.ok(r.slice(1).every(x=>x.quality==='assumed'&&x.assumedPeak));
 assert.ok(r.every(x=>!x.frequency&&x.departureLatest===x.departure&&x.arrivalLatest===x.arrival));
 for(const dir of ['toBN','toTNT']) {
  const next=E.shuttleRows(ref('2026-09-07','08:00'),dir,30);
  assert.deepEqual(next.map(x=>E.hhmm(x.departure)),['08:04','08:12','08:20','08:28']);
  assert.ok(next.every(x=>x.arrival-x.departure===480));
 }
});
test('Morning TNT peak is shifted +8 minutes, with no duplicate overlap',()=>{
 const r=E.shuttleRows(ref('2026-09-07','07:00'),'toBN',158);
 const expected=E.MORNING_PEAK.map(t=>E.hhmm(ref('2026-09-07',t)+480));
 assert.deepEqual(r.map(x=>E.hhmm(x.departure)),expected);
 assert.equal(r.filter(x=>E.hhmm(x.departure)==='07:08').length,1);
 assert.equal(r[0].quality,'derived');
 assert.ok(r.slice(1).every(x=>x.quality==='assumed'&&x.returnOffset===8));
 assert.equal(new Set(r.map(x=>x.id)).size,r.length);
});
test('Peak end clipping preserves the off-peak departures after the grid',()=>{
 const a=E.shuttleRows(ref('2026-09-07','09:20'),'toTNT',20);
 assert.deepEqual(a.map(x=>E.hhmm(x.departure)),['09:24','09:35']);
 const b=E.shuttleRows(ref('2026-09-07','09:28'),'toBN',20);
 assert.deepEqual(b.map(x=>E.hhmm(x.departure)),['09:32','09:43']);
 const c=E.shuttleRows(ref('2026-09-07','18:20'),'toBN',25);
 assert.deepEqual(c.map(x=>E.hhmm(x.departure)),['18:24','18:40']);
});
test('Afternoon TNT grid starts at 16:00; BN reverse times are not invented',()=>{
 assert.equal(E.shuttleRows(ref('2026-09-07','14:00'),'toBN',10)[0].departure,ref('2026-09-07','14:05'));
 const r=E.shuttleRows(ref('2026-09-07','16:00'),'toBN',150);
 assert.deepEqual(r.map(x=>E.hhmm(x.departure)),E.AFTERNOON_PEAK);
 assert.ok(r.every(x=>x.quality==='assumed'));
 assert.deepEqual(E.shuttleRows(ref('2026-09-07','16:30'),'toBN',20).map(x=>E.hhmm(x.departure)),['16:32','16:40','16:48']);
 assert.equal(E.shuttleRows(ref('2026-09-07','14:00'),'toTNT',300).length,0);
});
test('Confirmed lunch starts at TNT; all eight BN arrivals are +8 minutes',()=>{
 const r=E.shuttleRows(ref('2026-09-07','12:00'),'toBN',120);
 assert.equal(r.length,8);
 assert.deepEqual(r.map(x=>E.hhmm(x.departure)),E.LUNCH);
 assert.deepEqual(r.map(x=>E.hhmm(x.arrival)),['12:13','12:28','12:43','12:58','13:13','13:28','13:43','13:58']);
 assert.ok(r.every(x=>x.lunch&&x.quality==='confirmed'&&x.arrivalApprox&&x.origin.group==='shuttle'&&x.destination.group==='bn'));
 assert.ok(r.every(x=>x.headsign.includes('Rogier')));
 assert.equal(E.shuttleStatus(ref('2026-09-07','12:15'),'toBN').kind,'confirmed');
});
test('Rogier 12:16 and 12:32 are preserved exactly, with no later extrapolation',()=>{
 const r=E.shuttleRows(ref('2026-09-07','12:00'),'toBN',120);
 assert.equal(E.hhmm(r[0].rogierArrival),'12:16');
 assert.equal(E.hhmm(r[1].rogierArrival),'12:32');
 assert.equal(r[0].rogierArrival-r[0].departure,11*60);
 assert.equal(r[1].rogierArrival-r[1].departure,12*60);
 assert.ok(r.slice(2).every(x=>x.rogierArrival===null));
});
test('Lunch BN arrival times are not reverse departures to TNT',()=>{
 const r=E.shuttleRows(ref('2026-09-07','12:00'),'toTNT',120);
 assert.equal(r.length,0);
 assert.equal(E.shuttleStatus(ref('2026-09-07','12:13'),'toTNT').kind,'warning');
});
test('The unresolved 22:00 entry remains excluded; 21:40 is retained',()=>{
 for(const dir of ['toBN','toTNT']) assert.equal(E.shuttleRows(ref('2026-09-07','21:41'),dir,60).length,0);
 assert.equal(E.hhmm(E.shuttleRows(ref('2026-09-07','21:30'),'toBN',30)[0].departure),'21:40');
});
test('No weekend shuttle; holiday operations remain unconfirmed',()=>{
 assert.equal(E.shuttleRows(ref('2026-09-05','08:00'),'toBN',600).length,0);
 assert.equal(E.shuttleRows(ref('2026-11-11','08:00'),'toBN',600).length,0);
 assert.equal(E.shuttleStatus(ref('2026-11-11','08:00'),'toBN').kind,'warning');
 assert.equal(E.shuttleRows(ref('2027-09-07','08:00'),'toBN',600).length,0);
});
test('Official bus records provide both directions, correct stop order and dates',()=>{
 for(const dir of ['toBN','toTNT']) {
  const r=planned('2026-09-07','08:00',dir);
  for(const op of ['stib','delijn']) assert.ok(r.some(x=>x.operator===op));
  assert.ok(r.every(x=>(x.destination.group==='bn')===(dir==='toBN')));
  assert.ok(r.every(x=>x.arrival>=x.departure));
  assert.ok(r.every(x=>x.departure>=ref('2026-09-07','08:00')));
  for(const x of r.filter(x=>x.operator!=='shuttle')) assert.ok(x.destinationSequence>x.originSequence);
 }
});
test('Only STIB 14 and 20 actually connect; 20 does not serve Picard in feed',()=>{
 const r=planned('2026-09-07','08:00').filter(x=>x.operator==='stib');
 assert.deepEqual([...new Set(r.map(x=>x.line))].sort(),['14','20']);
 assert.ok(E.filterRows(r,{stop:'picard'}).every(x=>x.line==='14'));
});
test('GTFS exception additions override weekdays; removals override regular service',()=>{
 const fake={calendar:[{service_id:'regular',monday:'1',start_date:'20260101',end_date:'20261231'}],exceptions:[{service_id:'regular',date:'20260907',exception_type:'2'},{service_id:'extra',date:'20260907',exception_type:'1'}]};
 assert.deepEqual([...E.activeServices(fake,'2026-09-07')],['extra']);
});
test('Post-midnight services from the previous service day are included',()=>{
 const r=planned('2026-09-05','00:05');
 assert.ok(r.some(x=>x.serviceDate==='2026-09-04'));
 assert.ok(r.every(x=>x.departure>=ref('2026-09-05','00:05')));
});
test('No indefinite extrapolation beyond GTFS validity',()=>{
 assert.equal(planned('2026-12-07','08:00').filter(x=>x.operator!=='shuttle').length,0);
 assert.equal(planned('2026-09-28','08:00').filter(x=>x.operator==='stib').length,0);
});
test('All filters combine and shuttle eligibility toggle is respected',()=>{
 const r=planned('2026-09-07','08:00','toBN',{includeShuttle:false});
 assert.equal(r.some(x=>x.operator==='shuttle'),false);
 assert.ok(E.filterRows(r,{operator:'stib',stop:'picard'}).every(x=>x.operator==='stib'&&x.origin.group==='picard'));
});
test('Live predictions expire at 120 seconds, including the De Lijn feed timestamp',()=>{
 assert.equal(E.fresh({ok:true,fetchedAt:1000},1120),true);
 assert.equal(E.fresh({ok:true,fetchedAt:1000},1121),false);
 assert.equal(E.fresh({ok:true,fetchedAt:1100,feedTime:900},1120),false);
 assert.equal(E.fresh({ok:false,fetchedAt:1100},1120),false);
});
const base=planned('2026-09-07','08:00').find(x=>x.operator==='delijn');
const now=ref('2026-09-07','08:00');
const provider=u=>({ok:true,fetchedAt:now,feedTime:now,trips:{[base.tripId]:{date:E.dateKey(base.serviceDate),stops:[],...u}}});
test('De Lijn delay uses exact trip ID, date and explicit stop update',()=>{
 const live=E.applyDeLijn(base,provider({stops:[{stop:base.origin.id,seq:base.originSequence,relationship:0,departure:{delay:180}}]}),now);
 assert.equal(live.departure,base.departure+180);assert.equal(live.arrival,base.arrival+180);
 assert.equal(live.quality,'live');assert.equal(live.arrivalApprox,true);
});
test('De Lijn NO_DATA stops are not turned into predictions',()=>{
 const live=E.applyDeLijn(base,provider({stops:[{stop:base.origin.id,relationship:2,departure:{delay:180}}]}),now);
 assert.equal(live.quality,'scheduled');
});
test('GTFS trip cancellation enum is 3; skipped stop enum is 1',()=>{
 assert.equal(E.applyDeLijn(base,provider({relationship:3}),now).cancelled,true);
 assert.equal(E.applyDeLijn(base,provider({relationship:3,timestamp:now-3600}),now).cancelled,true);
 assert.equal(E.applyDeLijn(base,provider({relationship:'CANCELED'}),now).cancelled,true);
 assert.equal(E.applyDeLijn(base,provider({relationship:2}),now).cancelled,undefined);
 assert.equal(E.applyDeLijn(base,provider({stops:[{stop:base.origin.id,relationship:1}]}),now).cancelled,true);
});
test('STIB estimates are labelled live but do not invent a matched-trip delay',()=>{
 const rows=planned('2026-09-07','08:00'),r=rows.find(x=>x.operator==='stib');
 const p={ok:true,fetchedAt:now,records:[{stop:r.origin.id,line:r.line,time:r.departure+120,destination:{fr:r.headsign}}]};
 const result=E.applySTIB(rows,p,now).filter(x=>x.quality==='live');
 assert.ok(result.length>0);assert.equal(result[0].delay,null);assert.equal(result[0].tripId,null);assert.equal(result[0].arrivalApprox,true);
});
test('Planning mode never applies a live feed',()=>{
 const settings={reference:now,direction:'toBN',mode:'plan'};
 const r=E.allRows(D,settings,{providers:{delijn:provider({relationship:3})}},now);
 assert.ok(r.every(x=>!x.cancelled&&x.quality!=='live'));
});
test('Earliest-arrival and departure sorting are distinct; cancelled buses do not win',()=>{
 const rows=[{id:'a',departure:1,arrivalLatest:10,line:'1'},{id:'b',departure:2,arrivalLatest:4,line:'2'},{id:'c',departure:0,arrivalLatest:1,cancelled:true,line:'3'}];
 assert.equal(E.filterRows(rows,{sort:'arrival'})[0].id,'b');
 assert.equal(E.filterRows(rows,{sort:'departure'})[0].id,'a');
});
test('User walk profiles and exact reference pins are retained',()=>{
 assert.equal(W.profiles.picard.minutes,5);assert.equal(W.profiles.shuttle.minutes,5);assert.equal(W.profiles.suzan.minutes,8);
 assert.equal(W.profiles.picard.lat,50.86404643162095);assert.equal(W.profiles.picard.lon,4.343968608510816);
 assert.equal(W.profiles.shuttle.lat,50.86394437949276);assert.equal(W.profiles.shuttle.lon,4.346459999157837);
 assert.equal(W.profiles.suzan.lat,50.863076897694725);assert.equal(W.profiles.suzan.lon,4.346976807605478);
});
const homeSettings={reference:ref('2026-09-07','08:00'),direction:'toBN',mode:'plan',includeWalking:true,walking:W};
test('Walking filters out departures that cannot be reached from home',()=>{
 const r=E.allRows(D,homeSettings),unwalked=E.allRows(D,{...homeSettings,includeWalking:false});
 assert.ok(r.length<unwalked.length);
 assert.ok(r.every(x=>x.departure>=homeSettings.reference+x.walkMinutes*60));
 const best=E.filterRows(r)[0];
 assert.equal(best.operator,'stib');assert.equal(best.line,'14');assert.equal(best.origin.group,'picard');
 assert.equal(E.hhmm(best.departure),'08:06');assert.equal(E.hhmm(best.arrival),'08:12');
});
test('Latest home departure, wait and total avoid double-counting the walk',()=>{
 const best=E.filterRows(E.allRows(D,homeSettings))[0];
 assert.equal(best.walkMinutes,5);assert.equal(E.hhmm(best.leaveHomeBy),'08:01');
 assert.equal(E.hhmm(best.walkReadyAt),'08:05');assert.equal(best.waitAfterWalk,60);
 assert.equal(best.totalJourneySeconds,12*60);
 assert.equal(best.walkSeconds+best.waitAfterWalk+best.ride,best.totalJourneySeconds);
 assert.equal(best.arrival,ref('2026-09-07','08:12'));
});
test('A walk cut-off is exact, with no silent extra boarding buffer',()=>{
 const reference=ref('2026-09-07','12:00');
 const lunch=E.allRows(D,{...homeSettings,reference}).find(x=>x.operator==='shuttle');
 assert.equal(E.hhmm(lunch.departure),'12:05');assert.equal(E.hhmm(lunch.arrival),'12:13');
 assert.equal(lunch.waitAfterWalk,0);assert.equal(lunch.leaveHomeBy,reference);
 assert.equal(lunch.totalJourneySeconds,13*60);assert.equal(E.hhmm(lunch.rogierArrival),'12:16');
 const later=E.allRows(D,{...homeSettings,reference:reference+1}).find(x=>x.operator==='shuttle');
 assert.equal(E.hhmm(later.departure),'12:20');
});
test('The eight-minute Suzan Daniel estimate covers all approved operator platforms',()=>{
 const r=E.allRows(D,homeSettings).filter(x=>x.origin.group==='suzan');
 assert.ok(r.some(x=>x.operator==='stib'));assert.ok(r.some(x=>x.operator==='delijn'));
 assert.ok(r.every(x=>x.walkMinutes===8&&x.walkReference.lat===W.profiles.suzan.lat));
 for(const x of r){
  const original=D.operators[x.operator].stops[x.origin.id];
  assert.equal(x.origin.lat,original.lat);assert.equal(x.origin.lon,original.lon);
 }
 assert.ok(r.some(x=>x.origin.lon!==x.walkReference.lon));
});
test('TNT pickup uses the user pin without changing any BN shuttle bay',()=>{
 const r=E.allRows(D,homeSettings).find(x=>x.operator==='shuttle');
 assert.equal(r.origin.lat,W.profiles.shuttle.lat);assert.equal(r.origin.lon,W.profiles.shuttle.lon);
 assert.equal(r.destination.lat,undefined);
 const back=E.allRows(D,{...homeSettings,direction:'toTNT'}).find(x=>x.operator==='shuttle');
 assert.equal(back.destination.lat,W.profiles.shuttle.lat);assert.equal(back.origin.lat,undefined);
});
test('BN-to-TNT stays stop-to-stop even when Start from home preference is enabled',()=>{
 const withFlag=E.allRows(D,{...homeSettings,direction:'toTNT'});
 const withoutFlag=E.allRows(D,{...homeSettings,direction:'toTNT',includeWalking:false});
 assert.equal(E.walkingEnabled({...homeSettings,direction:'toTNT'}),false);
 assert.deepEqual(withFlag.map(x=>[x.id,x.departure,x.arrival]),withoutFlag.map(x=>[x.id,x.departure,x.arrival]));
 assert.ok(withFlag.every(x=>!x.walkingActive&&x.walkMinutes===0&&x.leaveHomeBy===null));
});
test('Walking can be switched off for an already-at-stop comparison',()=>{
 const r=E.allRows(D,{...homeSettings,includeWalking:false});
 assert.ok(r.every(x=>x.walkMinutes===0&&!x.walkingActive));
 assert.equal(E.filterRows(r)[0].line,'X60');
 assert.equal(E.hhmm(E.filterRows(r)[0].departure),'08:01');
});
test('A missing walking time is not silently counted as zero',()=>{
 const cfg={profiles:{...W.profiles}};delete cfg.profiles.suzan;
 const r=E.allRows(D,{...homeSettings,walking:cfg});
 assert.ok(r.every(x=>x.origin.group!=='suzan'));
});
test('Real-time delay is applied before walking reachability',()=>{
 const reference=homeSettings.reference;
 const original={...base,origin:{...base.origin,group:'picard'},departure:reference+240,scheduledDeparture:reference+240,arrival:reference+540,scheduledArrival:reference+540,ride:300,serviceDate:'2026-09-07'};
 assert.equal(E.applyWalking([original],homeSettings).length,0);
 const p={ok:true,fetchedAt:reference,feedTime:reference,trips:{[original.tripId]:{date:'20260907',stops:[{stop:original.origin.id,seq:original.originSequence,relationship:0,departure:{delay:120}}]}}};
 const updated=E.applyDeLijn(original,p,reference);
 const result=E.applyWalking([updated],homeSettings);
 assert.equal(result.length,1);assert.equal(result[0].quality,'live');
 assert.equal(result[0].leaveHomeBy,reference+60);assert.equal(result[0].arrival,reference+660);
});
console.log(`\n${count} engine tests passed.`);
