#!/usr/bin/env python3
"""Northbound personal dashboard. Run: python server.py --port 3000
No credentials needed. Live feeds are fetched on demand, at most once per minute.
Public-feed safeguards: 80 upstream calls / rolling 24h and 4 / rolling minute.
The remaining headroom is reserved for timetable downloads and source checks.
"""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import urlsplit
from datetime import datetime, timezone
import argparse, gzip, json, time, threading

ROOT = Path(__file__).resolve().parent
BASE = 'https://api-management-discovery-production.azure-api.net/api/'
STATE_PATH = ROOT / 'data' / 'live-state.json'
QUOTA_PATH = ROOT / 'data' / 'quota.json'
TTL = 60
STALE_AFTER = 120
LOCK = threading.Lock()
TIMETABLE = json.loads((ROOT / 'data' / 'timetable.json').read_text())
ENDPOINTS = {'stib': BASE + 'datasets/stibmivb/rt/WaitingTimes',
             'delijn': BASE + 'gtfs/feed/delijn/rt/trip-update'}


def load_json(path, default):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return default


def save_json(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, separators=(',', ':')))
    tmp.replace(path)


def long_number(value):
    if isinstance(value, dict):
        return (int(value.get('high', 0)) << 32) + (int(value.get('low', 0)) & 0xffffffff)
    return int(value) if value is not None else None


def normalize(op, body, fetched_at):
    d = TIMETABLE['operators'][op]
    if op == 'stib':
        if not isinstance(body, dict) or not isinstance(body.get('results'), list):
            raise ValueError('Unexpected STIB waiting-time response')
        records = []
        lines = {v['line'] for v in d['routes'].values()}
        for row in body['results']:
            if row.get('pointid') not in d['stops'] or row.get('lineid') not in lines:
                continue
            pts = row.get('passingtimes', [])
            if isinstance(pts, str):
                pts = json.loads(pts)
            for p in pts:
                destination = p.get('destination', {})
                # End-of-service sentinel rows have no destination and are NOT departures.
                if not destination or not p.get('expectedArrivalTime'):
                    continue
                msg = p.get('message', {})
                if 'end of service' in str(msg).lower() or 'service terminé' in str(msg).lower():
                    continue
                records.append({'stop': row['pointid'], 'line': p.get('lineId', row['lineid']),
                                'destination': destination,
                                'time': datetime.fromisoformat(p['expectedArrivalTime'].replace('Z', '+00:00')).timestamp(),
                                'message': msg.get('en', '') if isinstance(msg, dict) else str(msg)})
        return {'ok': True, 'fetchedAt': fetched_at, 'feedTime': None,
                'timestampNote': 'STIB does not expose a feed-generation timestamp here; time shown is the fetch time.',
                'records': records, 'source': ENDPOINTS[op]}
    if not isinstance(body, dict) or 'header' not in body:
        raise ValueError('Unexpected De Lijn trip-update response')
    updates = {}
    for e in body.get('entity', []):
        u = e.get('tripUpdate', e.get('trip_update', {}))
        trip = u.get('trip', {})
        tid = trip.get('tripId', trip.get('trip_id'))
        if tid not in d['trips']:
            continue
        relevant = []
        for call in u.get('stopTimeUpdate', u.get('stop_time_update', [])):
            sid = call.get('stopId', call.get('stop_id'))
            if sid not in d['stops']:
                continue
            rec = {'stop': sid, 'seq': call.get('stopSequence', call.get('stop_sequence')),
                   'relationship': call.get('scheduleRelationship', call.get('schedule_relationship', 0))}
            for event in ['arrival', 'departure']:
                if event in call:
                    ev = call[event]
                    rec[event] = {}
                    if 'time' in ev:
                        rec[event]['time'] = long_number(ev['time'])
                    if 'delay' in ev:
                        rec[event]['delay'] = long_number(ev['delay'])
            relevant.append(rec)
        updates[tid] = {'date': trip.get('startDate', trip.get('start_date')),
                        'relationship': trip.get('scheduleRelationship', trip.get('schedule_relationship', 0)),
                        'timestamp': long_number(u.get('timestamp')), 'stops': relevant}
    return {'ok': True, 'fetchedAt': fetched_at,
            'feedTime': long_number(body.get('header', {}).get('timestamp')),
            'trips': updates, 'source': ENDPOINTS[op]}


def fetch_provider(op):
    try:
        request = Request(ENDPOINTS[op], headers={'Accept': 'application/json', 'User-Agent': 'Northbound-personal-commute/1.0'})
        with urlopen(request, timeout=18) as response:
            raw = response.read(25 * 1024 * 1024)
        try:
            body = json.loads(raw)
        except (ValueError, UnicodeDecodeError):
            # The portal may deliver standard GTFS-RT protobuf rather than its JSON representation.
            if op != 'delijn':
                raise ValueError('Unexpected response format')
            from google.transit import gtfs_realtime_pb2
            from google.protobuf.json_format import MessageToDict
            feed = gtfs_realtime_pb2.FeedMessage()
            feed.ParseFromString(raw)
            body = MessageToDict(feed)
        return op, normalize(op, body, time.time())
    except HTTPError as exc:
        message = 'Public-feed rate limit reached; using the timetable.' if exc.code == 429 else f'Operator feed returned HTTP {exc.code}; using the timetable.'
    except Exception:
        message = 'Live feed temporarily unavailable; using the timetable.'
    return op, {'ok': False, 'attemptedAt': time.time(), 'error': message}


STATE = load_json(STATE_PATH, {'providers': {}, 'lastAttempt': 0})
QUOTA = load_json(QUOTA_PATH, {'calls': []})


def get_live(refresh=False):
    global STATE, QUOTA
    with LOCK:
        now = time.time()
        QUOTA['calls'] = [t for t in QUOTA.get('calls', []) if t > now - 86400]
        message = None
        age = now - STATE.get('lastAttempt', 0)
        if refresh and age >= TTL:
            recent = sum(t > now - 60 for t in QUOTA['calls'])
            if len(QUOTA['calls']) + 2 > 80:
                message = 'Daily live-refresh allowance reached. Scheduled departures remain available.'
            elif recent + 2 > 4:
                message = 'Please wait a minute before refreshing again.'
            else:
                QUOTA['calls'].extend([now, now])
                save_json(QUOTA_PATH, QUOTA)
                STATE['lastAttempt'] = now
                with ThreadPoolExecutor(max_workers=2) as pool:
                    results = list(pool.map(fetch_provider, ['stib', 'delijn']))
                for op, result in results:
                    # Failed data is never represented as a successful current prediction.
                    STATE.setdefault('providers', {})[op] = result
                save_json(STATE_PATH, STATE)
        elif refresh and age < TTL:
            message = 'Showing the shared cache. Live feeds can be refreshed once a minute.'
        return {**STATE, 'serverTime': time.time(), 'staleAfter': STALE_AFTER,
                'quota': {'used': len(QUOTA['calls']), 'limit': 80,
                          'refreshesLeft': max(0, (80 - len(QUOTA['calls'])) // 2),
                          'nextRefreshAt': STATE.get('lastAttempt', 0) + TTL},
                'notice': message}


class Handler(BaseHTTPRequestHandler):
    server_version = 'Northbound/1.0'

    def send(self, body, content_type='application/json; charset=utf-8', status=200, cache='no-store'):
        if isinstance(body, str):
            body = body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Cache-Control', cache)
        self.send_header('X-Content-Type-Options', 'nosniff')
        if 'gzip' in self.headers.get('Accept-Encoding', '') and len(body) > 2048:
            body = gzip.compress(body, compresslevel=5)
            self.send_header('Content-Encoding', 'gzip')
            self.send_header('Vary', 'Accept-Encoding')
        self.send_header('Content-Length', str(len(body)))
        # No frame/host/origin restrictions: Arena's HTTPS preview can embed this application.
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path in ('/', '/index.html'):
            html = (ROOT / 'Dashboard.html').read_text()
            html = html.replace('window.NORTHBOUND_SERVER = false;', 'window.NORTHBOUND_SERVER = true;')
            return self.send(html, 'text/html; charset=utf-8')
        if path == '/api/health':
            return self.send(json.dumps({'ok': True, 'app': 'Northbound', 'timezone': 'Europe/Brussels'}))
        if path == '/api/live':
            return self.send(json.dumps(get_live(refresh=False)))
        if path == '/shuttle.pdf':
            return self.send((ROOT / 'static' / 'shuttle.pdf').read_bytes(), 'application/pdf', cache='public, max-age=86400')
        if path == '/favicon.svg':
            return self.send('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="12" fill="#184e43"/><path d="M12 28V12l16 16V12" stroke="#d4f3c3" stroke-width="4" fill="none"/><circle cx="12" cy="12" r="3" fill="#d4f3c3"/><circle cx="28" cy="28" r="3" fill="#d4f3c3"/></svg>', 'image/svg+xml')
        return self.send(json.dumps({'error': 'Not found'}), status=404)

    def do_POST(self):
        if urlsplit(self.path).path != '/api/live/refresh':
            return self.send(json.dumps({'error': 'Not found'}), status=404)
        return self.send(json.dumps(get_live(refresh=True)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=3000)
    args = parser.parse_args()
    print(f'Northbound dashboard listening on 0.0.0.0:{args.port}', flush=True)
    ThreadingHTTPServer(('0.0.0.0', args.port), Handler).serve_forever()
