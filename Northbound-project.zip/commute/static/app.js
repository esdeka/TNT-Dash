(function () {
  'use strict';
  const E = window.CommuteEngine;
  const DATA = JSON.parse(document.getElementById('timetable-data').textContent);
  const WALKS = JSON.parse(document.getElementById('walking-data').textContent);
  const PDF = JSON.parse(document.getElementById('pdf-data').textContent);
  const FETCH_DATE = E.dateISO(Math.max(...Object.values(DATA.operators).map(d => Date.parse(d.fetchedAt || DATA.generatedAt) / 1000)));
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
  const safeURL = value => /^https?:\/\//i.test(value || '') ? esc(value) : '#';
  const OP_NAMES = { shuttle: 'T&T Shuttle', stib: 'MIVB / STIB', delijn: 'De Lijn' };
  const STOP_NAMES = { all: 'All stops', suzan: 'Suzan Daniel', picard: 'Picard', shuttle: 'T&T shuttle', bn: 'Brussels North' };
  const ICONS = {
    'arrow-right': '<path d="M4 12h15m-6-6 6 6-6 6"/>',
    'arrow-up-right': '<path d="M6 18 18 6M6 6h12v12"/>',
    'chevron-right': '<path d="m9 5 7 7-7 7"/>',
    'chevron-down': '<path d="m6 9 6 6 6-6"/>',
    'calendar': '<rect x="4" y="5" width="16" height="16" rx="3"/><path d="M8 3v4m8-4v4M4 11h16m-11 4h1m4 0h1"/>',
    'bolt': '<path d="m13 2-9 12h7l-1 8 10-13h-7l1-7Z"/>',
    'swap': '<path d="M4 7h16m-4-4 4 4-4 4M20 17H4m4-4-4 4 4 4"/>',
    'route': '<circle cx="6" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M6 9v6a3 3 0 0 0 3 3h6M10 6h8m-3-3 3 3-3 3"/>',
    'refresh': '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.3 8a7.5 7.5 0 0 1 12.4-3L20 8M4 16l2.3 3A7.5 7.5 0 0 0 18.7 16"/>',
    'bus': '<rect x="5" y="3" width="14" height="16" rx="3"/><path d="M5 11h14M8 19v2m8-2v2M9 7h6M8 15h.01M16 15h.01"/>',
    'info': '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
    'close': '<path d="m6 6 12 12M6 18 18 6"/>',
    'pin': '<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.5"/>',
    'sort': '<path d="M8 4v16m-3-3 3 3 3-3M16 20V4m-3 3 3-3 3 3"/>',
    'layers': '<path d="m12 3 10 6-10 6L2 9l10-6Zm-9 11 9 5 9-5M3 19l9 5 9-5" transform="translate(0 -1) scale(1 .94)"/>',
    'sparkles': '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>',
    'clock': '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    'moon': '<path d="M21 13.2A9 9 0 0 1 10.8 3 9 9 0 1 0 21 13.2Z"/>',
    'shield': '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/><path d="m8 12 3 3 5-6"/>',
    'download': '<path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/>',
    'check': '<path d="m5 12 4 4L19 6"/>',
    'warning': '<path d="m12 3 10 18H2L12 3Z"/><path d="M12 9v5m0 3h.01"/>',
    'train': '<rect x="5" y="3" width="14" height="15" rx="3"/><path d="M5 10h14m-10 4h.01m6 0h.01M9 18l-3 4m9-4 3 4M8 20h8"/>',
    'walking': '<circle cx="14" cy="4" r="2"/><path d="m8 22 3-8 4 4v4M5 12l4-3 4-2 3 6 4 1M11 14l2-7"/>'
  };
  function icon(name) { return `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.info}</svg>`; }
  function fillIcons(root = document) { root.querySelectorAll('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); }); }
  function loadPreferences() { try { return JSON.parse(localStorage.getItem('northbound:v1') || '{}'); } catch { return {}; } }
  const preferences = loadPreferences();
  const realNow = () => Date.now() / 1000;
  const state = {
    direction: preferences.direction === 'toTNT' ? 'toTNT' : 'toBN',
    includeShuttle: preferences.includeShuttle !== false,
    includeWalking: preferences.includeWalking !== false, walking: WALKS, hiddenByWalk: 0,
    mode: 'now', planDate: E.dateISO(realNow()), planTime: E.hhmm(realNow()),
    reference: realNow(), horizon: 120, operator: 'all', stop: 'all', sort: 'arrival',
    limit: 10, live: null, loading: false, networkError: false, allRows: [], filtered: [], best: null,
    dialogTab: null, dialogRow: null
  };
  function savePreferences() { try { localStorage.setItem('northbound:v1', JSON.stringify({direction: state.direction, includeShuttle: state.includeShuttle, includeWalking: state.includeWalking})); } catch {} }
  function dateLabel(epoch, style = 'long') {
    return new Intl.DateTimeFormat('en-GB', {timeZone: E.ZONE, weekday: style === 'long' ? 'long' : 'short', day: 'numeric', month: style === 'long' ? 'long' : 'short'}).format(new Date(epoch * 1000));
  }
  function shortDate(iso) { return new Intl.DateTimeFormat('en-GB', {day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC'}).format(new Date(`${iso}T12:00:00Z`)); }
  function dateSuffix(epoch) { const delta = Math.round((Date.parse(E.dateISO(epoch)) - Date.parse(E.dateISO(state.reference))) / 86400000); return delta > 0 ? ` +${delta}d` : ''; }
  function clock(epoch, suffix = false) { return E.hhmm(epoch) + (suffix ? dateSuffix(epoch) : ''); }
  const rideMinutes = row => Math.max(1, Math.ceil(row.ride / 60));
  function relative(epoch) {
    const seconds = epoch - state.reference;
    if (seconds < 0) return 'Departed';
    if (seconds < 45) return state.mode === 'now' ? 'Due now' : 'At selected time';
    const min = Math.ceil(seconds / 60);
    return `in ${min} min`;
  }
  function waitValue(row) {
    const min = Math.ceil((row.departure - state.reference) / 60);
    if (min < 1) return {number: 'Now', unit: ''};
    if (min >= 100) return {number: clock(row.departure), unit: ''};
    return {number: min, unit: 'min'};
  }
  function walkOn() { return E.walkingEnabled(state); }
  function durationText(seconds) {
    const n = Math.max(0, Math.round(seconds)), mins = Math.floor(n / 60), secs = n % 60;
    if (!secs) return `${mins} min`;
    return mins ? `${mins} min ${secs} sec` : `${secs} sec`;
  }
  function shortStop(stop) { return STOP_NAMES[stop.group] || stop.name; }
  function neighbourhoodStop(row) { return row.origin.group === 'bn' ? row.destination : row.origin; }
  function qualityText(row) {
    if (row.cancelled) return row.cancellationReason || 'Cancelled';
    if (row.quality === 'live') return 'Live estimate';
    if (row.quality === 'derived') return 'Derived +8 min';
    if (row.quality === 'assumed') return 'Assumed 8-min grid';
    if (row.quality === 'confirmed') return 'User-confirmed';
    return 'Scheduled';
  }
  function pill(row, short = false) {
    const shortLabels = { live: 'Live', derived: 'Derived +8', assumed: 'Assumed', confirmed: 'Confirmed' };
    const text = short ? shortLabels[row.quality] || qualityText(row) : qualityText(row);
    return `<span class="quality-pill ${esc(row.quality)}" title="${esc(qualityText(row))}">${row.quality === 'live' ? '<i class="inline-dot green"></i>' : ''}${esc(text)}</span>`;
  }
  function arrivalText(row, prefix = true) {
    const approx = prefix && (row.arrivalApprox || row.quality === 'live') ? '≈' : '';
    return approx + clock(row.arrival);
  }
  function depText(row) { return clock(row.departure); }
  function updateClock() {
    const now = realNow();
    $('local-clock').textContent = E.hhmm(now);
    $('today-weekday').textContent = new Intl.DateTimeFormat('en-GB', {timeZone: E.ZONE, weekday: 'long'}).format(new Date(now * 1000));
    $('today-date').textContent = new Intl.DateTimeFormat('en-GB', {timeZone: E.ZONE, day: 'numeric', month: 'long', year: 'numeric'}).format(new Date(now * 1000));
  }
  function renderPlanner() {
    const inbound = state.direction === 'toBN', walking = walkOn();
    $('origin-code').textContent = inbound ? 'TNT' : 'BN';
    $('destination-code').textContent = inbound ? 'BN' : 'TNT';
    $('origin-name').textContent = inbound ? 'Tour & Taxis' : 'Brussels North';
    $('destination-name').textContent = inbound ? 'Brussels North' : 'Tour & Taxis';
    $('origin-caption').textContent = inbound ? walking ? 'Home · Parkdreef · walk included' : 'At your neighbourhood stop' : 'Brussel-Noord / Bruxelles-Nord';
    $('destination-caption').textContent = inbound ? 'Brussel-Noord / Bruxelles-Nord' : 'Suzan Daniel / Picard / shuttle';
    document.querySelector('.swap-button').setAttribute('aria-label', `Reverse direction: ${inbound ? 'Brussels North to Tour and Taxis' : 'Tour and Taxis to Brussels North'}`);
    for (const mode of ['now', 'plan']) {
      const btn = $(mode === 'now' ? 'now-button' : 'plan-button');
      btn.classList.toggle('selected', state.mode === mode);
      btn.setAttribute('aria-pressed', String(state.mode === mode));
    }
    $('plan-fields').hidden = state.mode !== 'plan';
    if (document.activeElement !== $('plan-date')) $('plan-date').value = state.planDate;
    if (document.activeElement !== $('plan-time')) $('plan-time').value = state.planTime;
    $('include-shuttle').checked = state.includeShuttle;
    $('include-walking').checked = walking;
    $('include-walking').disabled = !inbound;
    $('walk-options').classList.toggle('inactive', !walking);
    $('walking-mode-help').textContent = !inbound ? 'Return trips stay stop-to-stop.' : walking ? 'Already at the stop? Turn this off.' : 'At the stop · walking is excluded.';
    $('when-label').textContent = walking ? 'WHEN WILL YOU LEAVE HOME?' : 'WHEN ARE YOU GOING?';
    $('plan-time-label').textContent = walking ? 'Leave home after' : 'Departure time';
    $('journey-scope').innerHTML = walking ? `${icon('walking')}Home → BN · walking included; platform access excluded` : `${icon('route')}Stop-to-stop · ${inbound ? 'walking switched off' : 'walk back home excluded'}`;
    const tz = new Intl.DateTimeFormat('en-GB', {timeZone: E.ZONE, timeZoneName: 'short'}).formatToParts(new Date(state.reference * 1000)).find(p => p.type === 'timeZoneName').value;
    const context = walking ? state.mode === 'now' ? 'Leave home now' : 'Leave home after' : state.mode === 'now' ? 'Leaving now' : 'Depart after';
    $('time-context').textContent = `${context} · ${dateLabel(state.reference, 'short')} · ${clock(state.reference)} ${tz}`;
  }
  function renderStatus() {
    const node = $('live-status'), button = $('refresh-button');
    button.classList.toggle('loading', state.loading);
    button.disabled = state.loading || state.mode === 'plan';
    $('refresh-label').textContent = state.loading ? 'Checking…' : window.NORTHBOUND_SERVER ? 'Refresh live' : 'Live sources';
    button.title = state.mode === 'plan' ? 'Live updates apply only in Leave now mode.' : 'Live feeds refresh on demand, with a 60-second shared cache.';
    let text, cls = '';
    if (state.mode === 'plan') text = state.includeShuttle ? 'Planning with timetables + your shuttle assumptions' : 'Planning with timetables · live delays not applied';
    else if (!window.NORTHBOUND_SERVER) text = 'Standalone copy · no live data';
    else if (state.loading) text = 'Checking MIVB / STIB and De Lijn feeds…';
    else {
      const providers = state.live?.providers || {};
      const liveCount = Object.values(providers).filter(p => E.fresh(p, realNow())).length;
      if (liveCount === 2) { text = state.allRows.some(r => r.quality === 'live') ? 'Live estimates + scheduled departures' : 'Feeds checked · no live prediction for listed trips'; cls = 'fresh'; }
      else if (liveCount === 1) { text = 'One live feed available · timetable fallback for the other'; cls = 'fresh'; }
      else if (Object.values(providers).some(p => p.ok)) { text = 'Live data is stale · using timetables and your assumptions'; cls = 'warning'; }
      else { text = state.networkError || state.live ? 'Live unavailable · timetable comparison remains available' : 'Timetable comparison · live not checked yet'; cls = state.networkError || state.live ? 'warning' : ''; }
    }
    node.className = `data-status ${cls}`;
    node.innerHTML = `<span class="status-dot"></span><span>${esc(text)}</span>`;
    const last = state.live?.lastAttempt;
    $('refresh-age').textContent = state.mode === 'now' && last ? `Checked ${clock(last)} · on demand` : '';
  }
  function renderCoverage() {
    const iso = E.dateISO(state.reference), key = E.dateKey(iso), notes = [];
    for (const [op, data] of Object.entries(DATA.operators)) {
      if (key < data.feedStart || key > data.feedEnd) notes.push(`${OP_NAMES[op]}: selected date is outside the saved timetable (${shortDate(E.dateFromKey(data.feedStart))}–${shortDate(E.dateFromKey(data.feedEnd))}). Missing times do not mean no service.`);
    }
    const status = E.shuttleStatus(state.reference, state.direction);
    if (state.includeShuttle && status.kind === 'warning') notes.push(`Shuttle: ${status.note} These unspecified departures remain excluded.`);
    $('coverage-notice').hidden = notes.length === 0;
    $('coverage-notice').innerHTML = notes.length ? `${icon('info')}<span>${notes.map(esc).join('<br>')}</span>` : '';
  }
  function renderRecommendation() {
    const best = state.best, container = $('recommendation');
    container.classList.toggle('empty', !best);
    container.classList.toggle('walking-summary', Boolean(best?.walkingActive));
    if (!best) {
      const filtered = state.operator !== 'all' || state.stop !== 'all';
      container.innerHTML = `<div class="recommendation-top"><span class="recommendation-eyebrow">${icon('moon')} A MOMENT BETWEEN CONNECTIONS</span><span class="recommendation-status">${state.mode === 'plan' ? 'Planned time' : 'Right now'}</span></div><div class="recommendation-content"><span class="empty-hero-icon">${icon('clock')}</span><h2>${filtered ? 'No match in this window.' : 'Nothing listed just yet.'}</h2><p>${filtered ? 'Try another stop or operator, or look a little further ahead.' : walkOn() ? 'No listed departure can be reached after your walk in this window. Try a later time, or turn off walking if you are already at the stop.' : 'There are no listed departures in this window. Check a later time or plan your next morning.'}</p></div><div class="recommendation-bottom"><p>Only your explicitly agreed shuttle assumptions are used.</p><button class="recommendation-button" data-action="${filtered ? 'reset-filters' : 'quick-plan'}" data-hour="08:00">${filtered ? 'Clear filters' : 'Plan a morning'} ${icon('arrow-right')}</button></div>`;
      return;
    }
    const timeTotal = Math.max(0, Math.ceil((best.arrival - state.reference) / 60));
    const bestTitle = best.operator === 'shuttle' ? 'Take the shuttle.' : `Take bus ${esc(best.line)}.`;
    const to = best.destination.group === 'bn' ? 'Brussels North' : shortStop(best.destination);
    const sourceText = qualityText(best);
    const walking = Boolean(best.walkingActive);
    let footnote = best.assumedPeak ? 'Your assumed 8-minute grid, not live. Staff eligibility required.' : best.lunch ? 'Staff only. Lunch departs TNT; BN arrival is estimated at +8 min.' : best.operator === 'shuttle' ? 'Staff only. Arrival uses your 8-minute ride time.' : best.quality === 'live' ? 'Operator estimate. Traffic can change the arrival time.' : 'Timetable estimate. Live delays may change this choice.';
    if (walking) footnote = best.assumedPeak ? `${best.walkMinutes}-min walk + your assumed shuttle times. Staff only; no extra boarding buffer.` : best.lunch ? `${best.walkMinutes}-min walk included. Lunch starts TNT; BN +8 min. Staff only.` : best.staffOnly ? `${best.walkMinutes}-min walk included. Staff only; allow extra time to board.` : `${best.walkMinutes}-min walk included. ${best.quality === 'live' ? 'Live bus estimate.' : 'Scheduled bus time.'} Allow extra time to board.`;
    else if ((state.operator !== 'all' || state.stop !== 'all') && !best.assumedPeak && !best.lunch) footnote = 'Earliest listed arrival within your active filters. ' + (best.staffOnly ? 'Staff only.' : 'Walking excluded.');
    container.innerHTML = `<div class="recommendation-top"><span class="recommendation-eyebrow">${icon('sparkles')} EARLIEST LISTED ARRIVAL</span><span class="recommendation-status">${best.quality === 'live' ? '<i class="inline-dot green"></i>' : ''}${esc(sourceText)}</span></div><div class="recommendation-content"><div class="arrival-total"><div class="big-number">${timeTotal}<span class="number-unit">min</span></div><p>${walking ? 'walk + wait + ride' : 'wait + ride'}<br>to ${esc(to)}</p></div><div class="recommended-route"><h2>${bestTitle}</h2><div class="route-from">${icon(walking ? 'walking' : 'pin')}${walking ? `${best.walkMinutes} min walk to ${esc(shortStop(best.origin))}` : `From ${esc(shortStop(best.origin))}`}</div>${walking ? `<div class="home-deadline">Leave home by <strong>${clock(best.leaveHomeBy)}</strong></div>` : ''}<div class="mini-journey"><div><small>${walking ? 'Bus leaves' : 'Leave'}</small><strong>${clock(best.departure)}</strong></div><div class="mini-journey-line"><span>${rideMinutes(best)} min ride</span><i></i></div><div><small>Arrive${dateSuffix(best.arrival)}</small><strong>${arrivalText(best)}</strong></div></div></div></div><div class="recommendation-bottom"><p>${esc(footnote)}</p><button class="recommendation-button" data-action="best">View option ${icon('arrow-right')}</button></div>`;
  }
  function logo(op) { return `<span class="operator-logo ${op}">${op === 'shuttle' ? 'T&T' : op === 'stib' ? 'M' : '<span>De Lijn</span>'}</span>`; }
  function renderOperators() {
    $('operator-cards').innerHTML = ['shuttle','stib','delijn'].map(op => {
      const rows = E.filterRows(state.allRows, {operator: op, stop: state.stop, sort: 'arrival'}).filter(r => !r.cancelled);
      const best = rows[0];
      let body, quality;
      if (best) {
        const wait = waitValue(best);
        const neighbourhood = shortStop(neighbourhoodStop(best));
        quality = pill(best, true);
        const tripName = best.lunch ? 'Lunch shuttle · via BN to Rogier' : best.assumedPeak ? `8-min grid · ${esc(neighbourhood)}` : `${best.operator === 'shuttle' ? 'Shuttle' : 'Bus ' + esc(best.line)} · ${esc(neighbourhood)}`;
        body = `<div class="operator-body"><div><div class="operator-time">${esc(wait.number)}<span>${esc(wait.unit)}</span></div><p class="operator-subtitle">${tripName}<br>Bus leaves ${clock(best.departure)} · ${rideMinutes(best)} min ride</p>${best.walkingActive ? `<p class="operator-home-plan">${best.walkMinutes} min walk · Leave home by <strong>${clock(best.leaveHomeBy)}</strong></p>` : ''}</div><div class="operator-right"><small>ARRIVES${dateSuffix(best.arrival) ? ' ' + dateSuffix(best.arrival) : ''}</small><strong>${arrivalText(best)}</strong></div></div>`;
      } else {
        const ss = E.shuttleStatus(state.reference, state.direction);
        let title = walkOn() ? 'No reachable departure' : 'No departures listed', sub = walkOn() ? 'Nothing in this window leaves enough time for your walk.' : 'Try a later time or a wider window.';
        if (op === 'shuttle' && !state.includeShuttle) { title = 'Shuttle excluded'; sub = 'Enable the staff shuttle below to compare it.'; }
        else if (state.stop !== 'all') { title = 'No matching option'; sub = `No ${OP_NAMES[op]} departures for this stop and time.`; }
        else if (op === 'shuttle' && ss.kind !== 'scheduled') { title = ss.title; sub = ss.note; }
        else if (op === 'shuttle') { sub = 'No listed departure in this window.'; }
        quality = `<span class="quality-pill ${op === 'shuttle' && ss.kind === 'warning' ? 'warning' : ''}">${op === 'shuttle' ? 'Staff only' : 'Timetable'}</span>`;
        body = `<div class="operator-body"><div><div class="operator-time text-state">${esc(title)}</div><p class="operator-subtitle">${esc(sub)}</p></div></div>`;
      }
      const foot = op === 'shuttle' ? 'Free · eligible staff only' : op === 'stib' ? 'Direct buses 14 & 20' : 'Direct trips from the current feed';
      return `<button class="operator-card ${state.operator === op ? 'active' : ''}" data-action="operator" data-operator="${op}" aria-pressed="${state.operator === op}" aria-label="${state.operator === op ? 'Clear' : 'Filter to'} ${OP_NAMES[op]}"><div class="operator-header">${logo(op)}<span class="operator-name">${OP_NAMES[op]}</span>${quality}</div>${body}<div class="operator-foot"><span>${foot}</span>${icon(state.operator === op ? 'close' : 'arrow-right')}</div></button>`;
    }).join('');
  }
  function renderTable() {
    const visible = state.filtered.slice(0, state.limit);
    $('departure-count').textContent = state.filtered.length;
    $('departures-subtitle').textContent = walkOn() ? 'Reachable from home · your walk is included. No changes.' : state.direction === 'toBN' ? 'Your neighbourhood stop → Brussels North. No changes.' : 'Board at Brussels North → your neighbourhood stop. Walk home excluded.';
    document.querySelector('.departures-table th:nth-child(2)').textContent = walkOn() ? 'BUS LEAVES' : 'LEAVES';
    document.querySelector('.departures-table th:first-child').textContent = state.direction === 'toBN' ? 'LINE / BOARD AT' : 'LINE / GET OFF AT';
    $('departure-rows').innerHTML = visible.map(row => {
      const localStop = neighbourhoodStop(row), best = row.id === state.best?.id;
      const liveOrData = row.quality === 'live' ? '<i class="mini-live-dot"></i>Live · ' : row.quality === 'derived' ? '+8 rule · ' : row.assumedPeak ? '8-min grid · ' : row.lunch ? 'Confirmed · ' : '';
      const tripLabel = relative(row.departure);
      const dir = state.direction === 'toBN' ? 'to BN' : 'from BN';
      const metadata = `${OP_NAMES[row.operator]} · ${dir}`;
      const metaHTML = row.walkingActive ? `${row.walkMinutes} min walk · ${row.assumedPeak ? 'Assumed grid' : row.lunch ? 'Confirmed lunch' : row.quality === 'derived' ? 'Derived +8' : row.quality === 'live' ? '<i class="mini-live-dot"></i>Live' : esc(OP_NAMES[row.operator])}` : liveOrData + esc(metadata);
      return `<tr class="${best ? 'best-row' : ''} ${row.cancelled ? 'cancelled' : ''}" data-row-id="${esc(row.id)}"><td><div class="line-stop"><span class="line-badge ${row.operator}">${esc(row.line)}</span><div><span class="boarding-stop">${esc(shortStop(localStop))}</span><span class="line-meta">${metaHTML}</span></div></div></td><td><span class="departure-time">${esc(depText(row))}</span><span class="relative-time">${row.cancelled ? esc(row.cancellationReason) : row.walkingActive ? 'Home by ' + clock(row.leaveHomeBy) : esc(tripLabel)}${dateSuffix(row.departure)}</span></td><td class="ride-col"><span class="ride-value">${rideMinutes(row)} min</span></td><td><span class="arrival-time">${arrivalText(row)}</span><span class="relative-time">${row.quality === 'live' || row.arrivalApprox ? 'Estimated' : 'Scheduled'}${dateSuffix(row.arrivalLatest)}</span></td><td class="data-col">${pill(row, true)}</td><td><button class="row-open" data-action="detail" data-id="${esc(row.id)}" aria-label="Details for ${esc(row.line)} via ${esc(shortStop(localStop))}, ${esc(depText(row))}">${icon('chevron-right')}</button></td></tr>`;
    }).join('');
    document.querySelectorAll('[data-action="stop"]').forEach(btn => { const selected = state.stop === btn.dataset.stop; btn.classList.toggle('selected', selected); btn.setAttribute('aria-pressed', String(selected)); });
    document.querySelectorAll('[data-map-stop]').forEach(g => g.classList.toggle('selected', g.dataset.mapStop === state.stop));
    $('sort').value = state.sort;
    $('horizon').value = state.horizon;
    $('active-filter').innerHTML = state.operator === 'all' ? '' : `<div class="active-filter-inner">Showing <button data-action="reset-operator">${OP_NAMES[state.operator]} ${icon('close')}</button><span>Click an operator card to compare another.</span></div>`;
    $('show-more').hidden = state.filtered.length <= state.limit;
    $('show-more').innerHTML = `Show ${Math.min(10, state.filtered.length - state.limit)} more ${icon('chevron-down')}`;
    $('rows-note').textContent = state.filtered.length ? `${visible.length} of ${state.filtered.length} boarding options · ${walkOn() ? 'earlier buses that you cannot walk to in time are hidden.' : 'one bus can appear at both stops.'}` : 'Your assumed shuttle times are labelled; live data is never fabricated.';
    $('empty-state').hidden = visible.length > 0;
    if (!visible.length) {
      const filtered = state.operator !== 'all' || state.stop !== 'all';
      $('empty-state').innerHTML = `<div class="empty-icon">${icon('bus')}</div><h3 class="empty-title">${filtered ? 'No departures match these filters.' : 'No departures listed in this window.'}</h3><p class="empty-description">${filtered ? 'Try all stops and operators, or choose a different departure time.' : 'The next connection may be later, or outside the saved timetable. Check the data dates above before assuming there is no service.'}</p><div class="empty-buttons">${filtered ? '<button data-action="reset-filters">Clear filters</button>' : ''}<button data-action="quick-plan" data-hour="08:00">Plan next workday</button><button data-action="modal" data-tab="sources">Check data coverage</button></div>`;
    }
  }
  function render() {
    const active = document.activeElement;
    const focus = active?.dataset?.action ? {action: active.dataset.action, id: active.dataset.id, op: active.dataset.operator, stop: active.dataset.stop} : null;
    state.reference = state.mode === 'now' ? realNow() : E.wallEpoch(state.planDate, state.planTime);
    const rawRows = E.allRows(DATA, {...state, includeWalking: false}, state.live, realNow());
    state.allRows = E.applyWalking(rawRows, state);
    state.hiddenByWalk = rawRows.length - state.allRows.length;
    state.filtered = E.filterRows(state.allRows, state);
    state.best = E.filterRows(state.filtered, {sort: 'arrival'}).find(r => !r.cancelled) || null;
    renderPlanner(); renderStatus(); renderCoverage(); renderRecommendation(); renderOperators(); renderTable();
    if (focus && !document.contains(active)) {
      const candidate = [...document.querySelectorAll(`[data-action="${focus.action}"]`)].find(el => el.dataset.id === focus.id && el.dataset.operator === focus.op && el.dataset.stop === focus.stop);
      candidate?.focus({preventScroll:true});
    }
  }
  let toastTimeout;
  function toast(text) { clearTimeout(toastTimeout); $('toast').textContent = text; $('toast').classList.add('visible'); toastTimeout = setTimeout(() => $('toast').classList.remove('visible'), 5000); }
  async function refreshLive(manual = false) {
    if (!window.NORTHBOUND_SERVER) { openModal('sources'); return; }
    if (state.loading || state.mode !== 'now') return;
    state.loading = true; state.networkError = false; renderStatus();
    try {
      const response = await fetch('/api/live/refresh', {method: 'POST', headers: {'Accept':'application/json'}, signal: AbortSignal.timeout(25000)});
      if (!response.ok) throw new Error('Live service unavailable');
      const payload = await response.json();
      if (!payload.providers || !payload.serverTime) throw new Error('Unexpected response');
      state.live = payload;
      if (manual) toast(payload.notice || 'Operator feeds checked. Only fresh predictions are labelled live.');
    } catch {
      state.networkError = true;
      state.live = null;
      if (manual) toast('Live feeds could not be reached. Published timetables are still available.');
    } finally {
      state.loading = false;
      render();
      if ($('details-dialog').open && state.dialogTab === 'sources') openModal('sources', true);
    }
  }
  function nextWorkday(hour) {
    // A quick plan is intentionally the NEXT calendar workday, not a rolling time today.
    let date = E.shiftDate(E.dateISO(realNow()), 1);
    while ([0,6].includes(E.dow(date)) || E.holiday(date)) date = E.shiftDate(date, 1);
    state.mode = 'plan'; state.planDate = date; state.planTime = hour; state.limit = 10;
    $('plan-error').textContent = ''; render();
    $('planner')?.scrollIntoView({behavior:'smooth',block:'start'});
  }
  function shiftedClock(t) { const [h,m] = t.split(':').map(Number); const min = h * 60 + m + 8; return `${String(Math.floor(min / 60)).padStart(2,'0')}:${String(min % 60).padStart(2,'0')}`; }
  function timeChips(times, derived = false) { return `<div class="time-chips ${derived ? 'derived' : ''}">${times.map(t => `<span class="time-chip">${esc(t)}</span>`).join('')}</div>`; }
  function pdfLink() { return window.NORTHBOUND_SERVER ? '/shuttle.pdf' : `data:application/pdf;base64,${PDF}`; }
  function shuttleContent() {
    return `<div class="notice">${icon('shield')}<span><strong>Staff-only service.</strong> The attached 2026 PDF restricts the shuttle to employees. On home → BN trips, your enabled walking estimates are included; BN → TNT remains stop-to-stop. Train-platform access is excluded. All shuttle arrival times use your <strong>8-minute ride estimate</strong>.</span></div><p><strong>Your latest rules are applied:</strong> use an anchored 8-minute grid during peak windows, and read the lunchtime first row as departures from TNT. Peak times are labelled <strong>Assumed</strong>; lunch departures are labelled <strong>User-confirmed</strong>. None is live-tracked.</p>
      <h3>Morning · BN → TNT</h3><p>Published BN departures outside the continuous-service grid (07:00 also appears in the PDF):</p>${timeChips(E.MORNING)}
      <p style="margin-top:12px"><strong>Assumed peak departures from BN:</strong> start at 07:00 and add 8 minutes, keeping only departures inside the 07:00–09:30 window.</p>${timeChips(E.MORNING_PEAK,true)}
      <p style="margin-top:9px">The final grid departure is <strong>09:24</strong>; the next listed BN departure is <strong>09:35</strong>. The grid does not reset at each hour: 07:56 is followed by 08:04, not 08:00.</p>
      <h3>Morning return · TNT → BN</h3><p>Published BN departure +8 minutes:</p>${timeChips(E.MORNING.map(shiftedClock),true)}
      <p style="margin-top:12px"><strong>Peak TNT departures = the assumed BN grid +8 minutes:</strong></p>${timeChips(E.MORNING_PEAK.map(shiftedClock),true)}
      <p style="margin-top:9px">These run from <strong>07:08 to 09:32</strong>, followed by the derived <strong>09:43</strong> departure. Overlapping entries at 07:00 from BN / 07:08 from TNT are shown only once in the departure board.</p>
      <h3>Lunch · TNT → BN → Rogier</h3><p>You confirmed that the first lunchtime row starts at <strong>TNT</strong>. BN arrival is TNT +8 minutes. The two Rogier estimates below are kept exactly as you supplied them.</p>
      <table class="schedule-table lunch-schedule"><thead><tr><th>TNT DEPARTURE<br>CONFIRMED BY YOU</th><th>BN ARRIVAL<br>ASSUMED +8 MIN</th><th>ROGIER ARRIVAL<br>YOUR ESTIMATE</th></tr></thead><tbody>${E.LUNCH.map(t => `<tr><td>${t}</td><td>≈${shiftedClock(t)}</td><td>${E.ROGIER_ESTIMATES[t] ? '≈' + E.ROGIER_ESTIMATES[t] : 'Not specified'}</td></tr>`).join('')}</tbody></table>
      <p style="margin-top:10px"><strong>12:16 and 12:32 at Rogier are arrival estimates, not TNT departures.</strong> They imply different offsets, so later Rogier arrivals have not been extrapolated. Rogier is continuation information only: the commute comparison still ends at BN. Lunchtime BN arrivals are not treated as BN → TNT departures.</p>
      <h3>Afternoon & evening · TNT → BN</h3><p>Published TNT departures:</p>${timeChips(E.AFTERNOON)}
      <p style="margin-top:12px"><strong>Assumed peak departures from TNT:</strong> start at 16:00 and add 8 minutes inside the 16:00–18:30 window.</p>${timeChips(E.AFTERNOON_PEAK,true)}
      <p style="margin-top:9px">The last grid departure is <strong>18:24</strong>; the next listed TNT departure is <strong>18:40</strong>. Every BN arrival adds 8 minutes to the TNT departure.</p>
      <h3>What remains unspecified</h3><table class="schedule-table"><thead><tr><th>PERIOD</th><th>REMAINING LIMITATION</th><th>DASHBOARD TREATMENT</th></tr></thead><tbody><tr class="warning-row"><td>Afternoon<br>BN → TNT</td>The afternoon table lists TNT → BN. The lunchtime route continues from BN to Rogier, not back to TNT.</td><td>No reverse departures assumed. Your +8-minute morning return rule is not applied here.</td></tr><tr class="warning-row"><td>22:00</td>The prose says last TNT 21:40 and last BN 22:00, but the TNT → BN table also lists 22:00.</td><td>The disputed 22:00 entry remains excluded in both directions. TNT 21:40 is retained.</td></tr><tr><td>Weekends / holidays</td>The official website lists weekday operation. Holiday arrangements are not stated.</td><td>No weekend shuttle. Holiday operation unconfirmed and not ranked.</td></tr></tbody></table>
      <a class="source-link" href="${pdfLink()}" download="TT-SHUTTLE-SCHEDULE.pdf">Download your original 2026 timetable ${icon('download')}</a>
      <div class="source-links"><a href="https://tour-taxis.com/your-visit/" target="_blank" rel="noopener noreferrer">[1] Official visiting information</a><a href="https://tour-taxis.com/wp-content/uploads/2026/01/TT-SHUTTLE-SCHEDULE.pdf" target="_blank" rel="noopener noreferrer">[2] Published 2026 PDF</a></div><p style="margin-top:16px">The original PDF is unchanged. Its conflicting lunch labels are resolved here by your confirmation. Exact peak-grid departures are your modelling assumption, not a new operator timetable; the PDF itself describes continuous service. Traffic and operational changes may affect actual trips.</p>`;
  }
  function sourceState(op) {
    if (!window.NORTHBOUND_SERVER) return '<span class="quality-pill">Offline timetable copy</span>';
    const p = state.live?.providers?.[op];
    if (E.fresh(p, realNow())) return '<span class="quality-pill live"><i class="inline-dot green"></i>Feed recently fetched</span>';
    if (p?.ok) return '<span class="quality-pill warning">Stale · not used as live</span>';
    return `<span class="quality-pill">${p?.error ? 'Live unavailable' : 'Not checked'}</span>`;
  }
  function sourcesContent() {
    const modeNotice = !window.NORTHBOUND_SERVER ? `<div class="notice">${icon('info')}<span><strong>This is the standalone copy.</strong> It contains real scheduled data and works without network access. Live feeds run only in the server-backed dashboard, shown in the live preview. No sample data is presented as live.</span></div>` : '';
    return modeNotice + `<p>Every departure has a provenance label. Bus routes are selected from official GTFS only when the same trip serves both your neighbourhood stop and Brussels North, in the right order, with boarding and alighting allowed.</p>` + ['stib','delijn'].map(op => {
      const d = DATA.operators[op], p = state.live?.providers?.[op];
      const lines = [...new Set(Object.values(d.routes).map(r => r.line))].sort((a,b)=>a.localeCompare(b,'en',{numeric:true}));
      const timeText = p?.fetchedAt ? `<br>Last successful live fetch: <strong>${dateLabel(p.fetchedAt,'short')}, ${clock(p.fetchedAt)}</strong> Brussels time.${p.feedTime ? `<br>Feed timestamp: ${dateLabel(p.feedTime,'short')}, ${clock(p.feedTime)}.` : '<br>STIB does not provide a generation timestamp in this endpoint; freshness is measured from fetch time.'}` : '';
      return `<section class="source-card"><div class="source-title"><h3>${OP_NAMES[op]}</h3>${sourceState(op)}</div><p><strong>Saved timetable:</strong> ${shortDate(E.dateFromKey(d.feedStart))}–${shortDate(E.dateFromKey(d.feedEnd))}.<br><strong>Direct route set:</strong> ${lines.map(esc).join(', ')}. Not every line runs at every stop, time or direction.<br><strong>Feed version:</strong> ${esc(d.feedVersion)}${timeText}${p?.error ? `<br>${esc(p.error)}` : ''}</p><div class="source-links"><a href="${safeURL(d.sourceUrl)}" target="_blank" rel="noopener noreferrer">GTFS timetable source</a><a href="https://data.belgianmobility.io/en/data.html?agency=${op === 'stib' ? 'stibmivb' : 'delijn'}" target="_blank" rel="noopener noreferrer">Official data catalogue</a><a href="${op === 'stib' ? 'https://www.stib-mivb.be/' : 'https://www.delijn.be/'}" target="_blank" rel="noopener noreferrer">Check operator notices</a></div><small>${esc(d.attribution)}</small></section>`;
    }).join('') + `<h3>Live, without pretending</h3><ul><li><strong>Refresh on demand.</strong> Opening the server-backed dashboard checks both feeds once. Use “Refresh live” to check again; requests within 60 seconds share a cache. There is no continuous background polling.</li><li><strong>Two-minute freshness limit.</strong> Older predictions are discarded from comparison and the published timetable is used. The De Lijn feed timestamp is checked as well as the fetch time. STIB exposes no feed-generation timestamp here.</li><li><strong>Public-feed quota:</strong> BMC allows anonymous access at 100 requests/day and 10/minute. This app caps live requests at 80 per rolling 24 hours and 4/minute, leaving headroom for timetable downloads.${state.live?.quota ? ` Current app allowance: ${state.live.quota.refreshesLeft} two-feed refreshes remaining.` : ''}</li><li><strong>Planned trips</strong> never use today’s live predictions. GTFS weekday calendars, date exceptions and post-midnight services are respected.</li><li><strong>Not a disruption monitor.</strong> De Lijn trip cancellations / skipped stops are applied when provided. No comprehensive service-alert feed is connected; check the operators before important journeys.</li></ul><h3>Keep the schedule current</h3><p>This copy was built from feeds downloaded on ${shortDate(FETCH_DATE)}. The date coverage above is enforced; schedules are not repeated outside their validity. To refresh the source project, run <code>python refresh_schedules.py</code>, then <code>python build.py</code> and restart the server. Large full-network archives are discarded from the deliverable.</p><div class="source-links"><a href="https://data.belgianmobility.io/en/terms.html" target="_blank" rel="noopener noreferrer">BMC terms & quotas</a><a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener noreferrer">CC BY 4.0 licence</a></div><p style="margin-top:15px">Timetables have been filtered and adapted for this personal dashboard. Sources: STIB-MIVB and De Lijn Open Data, updated ${shortDate(FETCH_DATE)}; your 2026 Tour & Taxis PDF; your 8-minute ride / morning-return rule, assumed 8-minute peak grid and lunchtime direction confirmation; your 5/5/8-minute walking estimates and stop pins, used only from home towards BN. Manrope font: SIL Open Font License 1.1. No location is tracked or sent from this dashboard.</p>`;
  }
  function methodContent() {
    return `<ol class="method-list"><li><div><strong>Start from home only when you choose to.</strong><p>On TNT → BN trips, “Start from home” includes your walk: 5 minutes to Picard, 5 minutes to the TNT shuttle, or 8 minutes to any nearby Suzan Daniel platform. A departure is reachable only if it leaves at or after the selected time plus that walk. Turn the switch off if you are already at the stop. On BN → TNT, the comparison always stays stop-to-stop, as you requested; it does not add a walk back home. Train-platform access and an extra boarding buffer are excluded.</p></div></li><li><div><strong>Find a real, direct connection.</strong><p>The route must serve the departure and arrival stops, in the right sequence, on that date. STIB lines 14 and 20 connect to BN in this feed. Neighbouring lines that do not make this connection are not ranked.</p></div></li><li><div><strong>Use a live prediction only when it exists.</strong><p>STIB gives the next two expected arrivals at a stop, without trip IDs. Its arrival at the other end is estimated using the ride time of a nearby matching scheduled service. No STIB delay is invented. De Lijn updates are matched by exact trip ID and service date. Explicit NO_DATA updates are never presented as live.</p></div></li><li><div><strong>Compare arrival, not just departure.</strong><p>The recommendation is the earliest listed arrival among the active filters. A bus leaving later may arrive first. Peak shuttle departures follow your explicitly requested eight-minute grid anchored at 07:00 from BN and 16:00 from TNT. Each assumed departure uses your 8-minute ride estimate. When starting from home, the walk is checked first, then the remaining wait and ride are counted. The walk is never added twice: total time is still the absolute BN arrival minus your selected home departure time. Live predictions are applied before checking whether you can reach a bus.</p></div></li><li><div><strong>Distinguish a vehicle from a boarding option.</strong><p>The same bus may be listed once at Picard and again at Suzan Daniel. Each row is a different boarding option, not another vehicle. On the return trip, rows can be two different drop-off stops on the same vehicle.</p></div></li><li><div><strong>Be explicit about uncertainty.</strong><p>“≈” means an estimated arrival. Bus ride time varies by trip and time of day; displayed minutes are rounded up. Shuttle travel takes 8 minutes under your assumption. Your confirmation resolves the lunchtime first row as TNT departures; BN arrivals use +8 minutes. The 22:00 conflict and unpublished afternoon reverse departures remain excluded. Rogier 12:16 and 12:32 are your supplied arrival estimates; later Rogier times are not extrapolated. Traffic, eligibility and service changes still matter.</p></div></li></ol><h3>Reading the labels</h3><p>${pill({quality:'live'})} a fresh operator prediction.<br>${pill({quality:'scheduled'})} a published timetable, with no live delay applied.<br>${pill({quality:'derived'})} your morning BN-departure +8-minute return rule.<br>${pill({quality:'assumed'})} a departure from your assumed eight-minute peak grid, not a published exact time.<br>${pill({quality:'confirmed'})} a lunchtime TNT departure confirmed by you; the BN arrival remains an 8-minute estimate.<br>${pill({quality:'cancelled',cancelled:true,cancellationReason:'Cancelled'})} a cancellation supplied by the De Lijn trip-update feed.</p>`;
  }
  function stopsContent() {
    const inbound = state.direction === 'toBN';
    let content = `<div class="notice">${icon('pin')}<span>Showing stop IDs for <strong>${inbound ? 'TNT → BN' : 'BN → TNT'}</strong>. The area illustration is schematic. Bus boarding coordinates below come from the operators’ GTFS feeds; your separate walking-reference pins and the supplied TNT shuttle pin are available under “Your walks”.</span></div>`;
    for (const op of ['stib','delijn']) {
      const d = DATA.operators[op], boarding = new Set(), arriving = new Set();
      for (const leg of d.legs) {
        if (inbound !== (d.stops[leg[2]].group === 'bn')) continue;
        boarding.add(leg[1]); arriving.add(leg[2]);
      }
      content += `<h3>${OP_NAMES[op]}</h3><div class="stop-list">`;
      for (const id of [...new Set([...boarding,...arriving])].sort((a,b) => d.stops[a].group.localeCompare(d.stops[b].group))) {
        const s = d.stops[id];
        const routes = new Set();
        for (const leg of d.legs) {
          if (inbound !== (d.stops[leg[2]].group === 'bn') || (leg[1] !== id && leg[2] !== id)) continue;
          routes.add(d.routes[d.trips[leg[0]][0]].line);
        }
        content += `<div class="stop-list-item"><span class="stop-code">${esc(s.code)}</span><div><strong>${esc(s.name)}</strong><p>${boarding.has(id) ? 'Board here' : 'Get off here'} · ${[...routes].sort((a,b)=>a.localeCompare(b,'en',{numeric:true})).map(esc).join(', ')}<br>${s.lat.toFixed(6)}, ${s.lon.toFixed(6)}</p></div><a href="https://www.google.com/maps/search/?api=1&query=${s.lat},${s.lon}" target="_blank" rel="noopener noreferrer">Find stop ↗</a></div>`;
      }
      content += '</div>';
    }
    return content + `<h3>Your TNT shuttle stop</h3><div class="stop-list-item"><span class="stop-code">T&T</span><div><strong>User-provided pickup pin</strong><p>${WALKS.profiles.shuttle.lat}, ${WALKS.profiles.shuttle.lon}<br>5-minute walk from home. No return walk is included.</p></div><a href="https://www.google.com/maps/search/?api=1&query=${WALKS.profiles.shuttle.lat},${WALKS.profiles.shuttle.lon}" target="_blank" rel="noopener noreferrer">Find stop ↗</a></div><p>The precise BN shuttle bay is still not supplied. The bus platforms above have not been overwritten with your walking-reference pins.</p><button class="source-link" style="width:100%" data-action="modal" data-tab="walking">Your walking times & reference pins ${icon('arrow-right')}</button>`;
  }
  function walkingContent() {
    return `<div class="notice">${icon('walking')}<span><strong>Only when leaving home towards BN.</strong> These are your walking estimates from Parkdreef. You asked to keep BN → TNT stop-to-stop, with no walk home added.</span></div>
      <p>“Start from home” filters out buses that depart before you can walk to their stop. The board and recommendation show the latest time to leave home. If you are already at a stop, switch walking off.</p>
      <div class="walking-pin-list">${['picard','shuttle','suzan'].map(key=>{
        const p=WALKS.profiles[key];
        return `<section class="walking-pin-card"><div class="walking-pin-heading"><span>${icon('pin')}</span><h3>${esc(p.name)}</h3><strong>${p.minutes}<small> min walk</small></strong></div><p>${esc(p.note)}</p><p class="coordinate-value">${p.lat}, ${p.lon}</p><a class="source-link" href="https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lon}" target="_blank" rel="noopener noreferrer">Open your reference pin ${icon('arrow-up-right')}</a></section>`;
      }).join('')}</div>
      <h3>One stop name can have several platforms</h3><p>Your Suzan Daniel pin is on Picard street. You confirmed that <strong>8 minutes should apply to all nearby Suzan Daniel platforms</strong>, including De Lijn. This is an area walking estimate; each bus retains its own stop ID and actual GTFS boarding coordinates in its trip details. The same approach uses your 5-minute Picard walk for the northbound Picard boarding stops. Your TNT pin supplies the previously missing shuttle-stop location.</p>
      <h3>How the minutes add up</h3><ol><li><strong>Ready at the stop</strong> = selected home departure time + walking time.</li><li><strong>Reachable bus</strong> = bus departure at or after that ready time, using a fresh live prediction when available.</li><li><strong>Leave home by</strong> = bus departure − walking time. No extra boarding buffer is deducted.</li><li><strong>Total time</strong> = walk + wait after the walk + ride. This equals BN arrival − selected home departure time; walking is not added to the arrival again.</li></ol><p>Example: leave home at 08:00, walk 5 minutes, board at 08:06, and arrive at 08:12. That is <strong>5 min walking + 1 min waiting + 6 min riding = 12 min</strong>. Alternatively, leave home by 08:01 for that same bus; the one-minute spare time can be spent at home.</p>
      <p style="margin-top:13px"><strong>Allow a safety margin.</strong> Walking times and live departures are estimates. The model allows arriving exactly at the departure time and adds no boarding buffer. Road crossings, slow walking or train-platform access may require extra time. No route from your home is tracked or sent to a map service.</p>`;
  }
  function openModal(tab, preserve = false) {
    const dlg = $('details-dialog');
    state.dialogTab = tab; state.dialogRow = null;
    const titles = {shuttle:'The shuttle, decoded.',sources:'Good decisions need good data.',method:'A fair comparison.',stops:'The right stop. The right direction.',walking:'Your walk. Your starting point.'};
    $('dialog-title').textContent = titles[tab] || titles.sources;
    $('dialog-eyebrow').textContent = 'NORTHBOUND / FIELD NOTES';
    $('dialog-tabs').innerHTML = [['shuttle','Shuttle timetable'],['sources','Data sources'],['method','How it works'],['walking','Your walks'],['stops','Stop details']].map(([key,label]) => `<button data-action="modal" data-tab="${key}" class="${key===tab?'active':''}" aria-pressed="${key===tab}">${label}</button>`).join('');
    const scroll = $('dialog-content').scrollTop;
    $('dialog-content').innerHTML = tab === 'shuttle' ? shuttleContent() : tab === 'method' ? methodContent() : tab === 'stops' ? stopsContent() : tab === 'walking' ? walkingContent() : sourcesContent();
    $('dialog-content').scrollTop = preserve ? scroll : 0;
    if (!dlg.open) dlg.showModal();
  }
  function showDetail(row) {
    if (!row) { toast('That departure has moved out of the current window. Choose another option.'); return; }
    const dlg = $('details-dialog');
    state.dialogTab = 'detail'; state.dialogRow = row;
    $('dialog-title').textContent = `${shortStop(row.origin)} → ${shortStop(row.destination)}`;
    $('dialog-eyebrow').textContent = row.walkingActive ? 'YOUR CONNECTION / HOME TO BN' : 'YOUR CONNECTION / STOP TO STOP';
    $('dialog-tabs').innerHTML = '';
    const fullRide = row.ride % 60 ? `${Math.floor(row.ride/60)} min ${Math.round(row.ride%60)} sec` : `${Math.round(row.ride/60)} min`;
    const maps = row.origin.lat ? `<a class="source-link" href="https://www.google.com/maps/search/?api=1&query=${row.origin.lat},${row.origin.lon}" target="_blank" rel="noopener noreferrer">Find boarding stop ${esc(row.origin.code)} ${icon('arrow-up-right')}</a>` : '<button class="source-link" style="width:100%" data-action="modal" data-tab="shuttle">Read the shuttle timetable & eligibility notes <span>↗</span></button>';
    $('dialog-content').innerHTML = `<div class="detail-route"><span class="line-badge ${row.operator}">${esc(row.line)}</span><div><h3>${OP_NAMES[row.operator]}</h3><p>Vehicle destination: ${esc(row.headsign)}</p></div><span style="margin-left:auto">${pill(row)}</span></div>${row.walkingActive ? `<section class="walking-detail"><div class="walk-deadline-card"><span>${icon('walking')}Leave home by</span><strong>${clock(row.leaveHomeBy)}</strong><small>${row.walkMinutes} min walk to ${esc(shortStop(row.origin))}</small></div><div class="journey-breakdown"><span><strong>${row.walkMinutes} min</strong>walk</span><i>+</i><span><strong>${durationText(row.waitAfterWalk)}</strong>wait after walking</span><i>+</i><span><strong>${durationText(row.ride)}</strong>ride</span><i>=</i><span><strong>${durationText(row.totalJourneySeconds)}</strong>from selected time</span></div><p>Ready at the stop at ${clock(row.walkReadyAt)} if you leave at ${clock(state.reference)}. Your walk is not added to the bus arrival a second time. No additional boarding buffer.</p></section>` : ''}${row.cancelled ? `<div class="notice">${icon('warning')}<span><strong>${esc(row.cancellationReason)}.</strong> This trip is not recommended. Pick another departure.</span></div>` : ''}<div class="detail-journey"><div><small>BOARD AT ${esc(shortStop(row.origin).toUpperCase())}</small><strong>${clock(row.departure)}</strong><p>${esc(relative(row.departure))}${dateSuffix(row.departure)}</p></div><span>${icon('arrow-right')}</span><div><small>ARRIVE AT ${esc(shortStop(row.destination).toUpperCase())}</small><strong>${arrivalText(row)}</strong><p>${esc(fullRide)} ride${dateSuffix(row.arrivalLatest)}</p></div></div><div class="detail-meta"><div><span>BOARDING STOP</span><strong>${esc(row.origin.name)} · ${esc(row.origin.code || 'See site signage')}</strong></div><div><span>ARRIVAL STOP</span><strong>${esc(row.destination.name)} · ${esc(row.destination.code || 'See site signage')}</strong></div><div><span>DATA BASIS</span><strong>${esc(qualityText(row))}${row.returnOffset ? ` · BN ${clock(row.baseDeparture)} +8 min` : ''}</strong></div><div><span>JOURNEY DATE</span><strong>${esc(dateLabel(row.departure))} · Brussels time</strong></div></div><h3>What this time means</h3><p class="detail-footnote">${esc(row.detail)}</p>${row.message ? `<p style="margin-top:9px"><strong>Operator message:</strong> ${esc(row.message)}</p>` : ''}${row.lunch ? `<section class="lunch-continuation"><h3>Continues to Rogier</h3><table class="schedule-table"><thead><tr><th>TNT DEPARTS</th><th>BN ARRIVES</th><th>ROGIER ARRIVES</th></tr></thead><tbody><tr><td>${clock(row.departure)}</td><td>${arrivalText(row)}</td><td>${row.rogierArrival ? '≈' + clock(row.rogierArrival) : 'Not specified'}</td></tr></tbody></table><p style="margin-top:9px">${row.rogierArrival ? 'Rogier time is your supplied arrival estimate.' : 'No Rogier arrival estimate was supplied for this trip.'} The dashboard compares only the TNT → BN leg. BN is an arrival on the way to Rogier, not a departure back to TNT.</p></section>` : ''}${row.delay !== null && row.delay !== undefined && Math.abs(row.delay) >= 60 ? `<p style="margin-top:9px"><strong>De Lijn prediction:</strong> ${Math.round(Math.abs(row.delay)/60)} min ${row.delay > 0 ? 'later' : 'earlier'} than the matched scheduled trip.</p>` : ''}<div class="notice" style="margin-top:19px">${icon(row.staffOnly?'shield':'walking')}<span>${row.staffOnly?'<strong>Staff eligibility required.</strong> The PDF restricts the shuttle to employees. ':''}${row.walkingActive ? 'Your walking estimate is included. There is no extra boarding buffer, and access to train platforms is excluded. Leave earlier if you need a safety margin.' : 'Walking and train-platform access are excluded from this stop-to-stop comparison. Be at the stop before the departure shown.'}</span></div>${maps}<p style="margin-top:17px" class="detail-footnote">${row.operator==='shuttle'?'Source: your Tour & Taxis 2026 timetable + your ride / return rules, peak-grid assumption and lunchtime confirmation.':'Source: '+esc(DATA.operators[row.operator].attribution)}${row.fetchedAt?` Live feed fetched ${clock(row.fetchedAt)}; this detail is a snapshot of that prediction.`:''}</p>`;
    $('dialog-content').scrollTop = 0;
    if (!dlg.open) dlg.showModal();
  }
  document.addEventListener('click', event => {
    const map = event.target.closest('[data-map-stop]');
    if (map) { state.stop = state.stop === map.dataset.mapStop ? 'all' : map.dataset.mapStop; state.limit = 10; render(); return; }
    const btn = event.target.closest('[data-action]');
    if (!btn || btn.disabled) return;
    switch (btn.dataset.action) {
      case 'swap': state.direction = state.direction === 'toBN' ? 'toTNT' : 'toBN'; state.limit=10; savePreferences(); render(); break;
      case 'mode': {
        const prior = state.mode; state.mode=btn.dataset.mode;
        if (prior !== state.mode && state.mode === 'plan') { state.planDate=E.dateISO(realNow()); state.planTime=E.hhmm(realNow()); }
        state.limit=10; render();
        if (state.mode === 'now' && prior !== 'now' && window.NORTHBOUND_SERVER) refreshLive();
        break;
      }
      case 'quick-plan': nextWorkday(btn.dataset.hour || '08:00'); break;
      case 'refresh': refreshLive(true); break;
      case 'operator': state.operator = state.operator === btn.dataset.operator ? 'all' : btn.dataset.operator; state.limit=10; render(); break;
      case 'stop': state.stop=btn.dataset.stop; state.limit=10; render(); break;
      case 'reset-filters': state.stop='all'; state.operator='all'; state.limit=10; render(); break;
      case 'reset-operator': state.operator='all'; state.limit=10; render(); break;
      case 'more': state.limit += 10; render(); break;
      case 'best': showDetail(state.best); break;
      case 'detail': showDetail(state.filtered.find(r=>r.id===btn.dataset.id)); break;
      case 'modal': openModal(btn.dataset.tab || 'sources'); break;
      case 'close-dialog': $('details-dialog').close(); break;
    }
  });
  document.querySelectorAll('[data-map-stop]').forEach(el => el.addEventListener('keydown', event => { if (event.key==='Enter' || event.key===' ') { event.preventDefault(); el.dispatchEvent(new MouseEvent('click',{bubbles:true})); } }));
  $('details-dialog').addEventListener('click', event => { if (event.target === $('details-dialog')) { const rect=$('details-dialog').getBoundingClientRect(); if (event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom) $('details-dialog').close(); } });
  $('horizon').addEventListener('change', event => { state.horizon=+event.target.value; state.limit=10; render(); });
  $('sort').addEventListener('change', event => { state.sort=event.target.value; render(); });
  $('include-walking').addEventListener('change', event => { state.includeWalking=event.target.checked; state.limit=10; savePreferences(); render(); });
  $('include-shuttle').addEventListener('change', event => { state.includeShuttle=event.target.checked; state.limit=10; savePreferences(); render(); });
  function planChange() {
    if (!$('plan-date').value || !$('plan-time').value || !$('plan-date').validity.valid || !$('plan-time').validity.valid) { $('plan-error').textContent='Choose a valid date and time.'; return; }
    state.planDate=$('plan-date').value; state.planTime=$('plan-time').value; state.mode='plan'; state.limit=10; $('plan-error').textContent=''; render();
  }
  $('plan-date').addEventListener('change', planChange); $('plan-time').addEventListener('change', planChange);
  fillIcons(); updateClock(); render();
  document.querySelector('.app-footer button').innerHTML = `Operator data · ${shortDate(FETCH_DATE)} · CC BY 4.0 ${icon('arrow-up-right')}`;
  if (window.NORTHBOUND_SERVER) refreshLive();
  let lastBucket = Math.floor(realNow()/15);
  setInterval(() => {
    updateClock();
    if (state.mode === 'now' && !document.hidden && Math.floor(realNow()/15) !== lastBucket) { lastBucket=Math.floor(realNow()/15); render(); }
  }, 1000);
  // Expose read-only debug information for reproducible tests, without network credentials.
  window.Northbound = { getSnapshot: () => ({direction:state.direction,mode:state.mode,reference:state.reference,includeWalking:state.includeWalking,walkingActive:walkOn(),hiddenByWalk:state.hiddenByWalk,count:state.filtered.length,best:state.best,live:state.live,rows:state.filtered}), engine:E };
})();
