/* Northbound's timetable engine. All timestamps are epoch seconds.
   Pure functions; no DOM, network, timers or fabricated live data. */
(function (root) {
  'use strict';
  const ZONE = 'Europe/Brussels';
  const formatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: ZONE, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
  });
  const pad = n => String(n).padStart(2, '0');
  function parts(epoch) {
    return Object.fromEntries(formatter.formatToParts(new Date(epoch * 1000))
      .filter(p => p.type !== 'literal').map(p => [p.type, p.value]));
  }
  function dateISO(epoch) { const p = parts(epoch); return `${p.year}-${p.month}-${p.day}`; }
  function hhmm(epoch) { const p = parts(epoch); return `${p.hour}:${p.minute}`; }
  function wallEpoch(iso, time = '00:00') {
    const [y, m, d] = iso.split('-').map(Number);
    const [h, min, sec = 0] = time.split(':').map(Number);
    const target = Date.UTC(y, m - 1, d, h, min, sec) / 1000;
    let guess = target;
    for (let i = 0; i < 3; i++) {
      const p = parts(guess);
      const represented = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) / 1000;
      guess += target - represented;
    }
    return guess;
  }
  // GTFS defines its service-day origin as local noon minus 12 hours (including on DST days).
  function serviceBase(iso) { return wallEpoch(iso, '12:00') - 12 * 3600; }
  function shiftDate(iso, delta) {
    const [y, m, d] = iso.split('-').map(Number);
    return new Date(Date.UTC(y, m - 1, d + delta, 12)).toISOString().slice(0, 10);
  }
  function dateKey(iso) { return iso.replaceAll('-', ''); }
  function dateFromKey(key) { return `${key.slice(0, 4)}-${key.slice(4, 6)}-${key.slice(6, 8)}`; }
  function dow(iso) { return new Date(`${iso}T12:00:00Z`).getUTCDay(); }
  function activeServices(data, iso) {
    const key = dateKey(iso), result = new Set();
    const day = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][dow(iso)];
    for (const c of data.calendar) {
      if (c.start_date <= key && c.end_date >= key && c[day] === '1') result.add(c.service_id);
    }
    for (const c of data.exceptions) {
      if (c.date === key) c.exception_type === '1' ? result.add(c.service_id) : result.delete(c.service_id);
    }
    return result;
  }
  function fresh(provider, now, maxAge = 120) {
    if (!provider?.ok || !provider.fetchedAt || now - provider.fetchedAt > maxAge || provider.fetchedAt - now > 30) return false;
    return !provider.feedTime || (now - provider.feedTime <= maxAge && provider.feedTime - now < 30);
  }
  const relIs = (v, n, s) => v === n || v === s || v === String(n);
  function eventTime(ev, scheduled) {
    if (!ev) return null;
    if (Number.isFinite(ev.time) && ev.time > 0) return ev.time;
    if (Number.isFinite(ev.delay)) return scheduled + ev.delay;
    return null;
  }
  function applyDeLijn(row, provider, now) {
    if (!fresh(provider, now)) return row;
    const u = provider.trips?.[row.tripId];
    if (!u || (u.date && u.date !== dateKey(row.serviceDate))) return row;
    if (relIs(u.relationship, 1, 'ADDED') || relIs(u.relationship, 2, 'UNSCHEDULED') || relIs(u.relationship, 6, 'DUPLICATED')) return row;
    const a = u.stops.find(s => s.stop === row.origin.id && (!s.seq || +s.seq === row.originSequence));
    const b = u.stops.find(s => s.stop === row.destination.id && (!s.seq || +s.seq === row.destinationSequence));
    if (relIs(u.relationship, 3, 'CANCELED') || relIs(u.relationship, 7, 'DELETED')) {
      return { ...row, cancelled: true, cancellationReason: 'Cancelled', quality: 'cancelled' };
    }
    if (relIs(a?.relationship, 1, 'SKIPPED') || relIs(b?.relationship, 1, 'SKIPPED')) {
      return { ...row, cancelled: true, cancellationReason: 'Stop skipped', quality: 'cancelled' };
    }
    // An unchanged cancellation / skipped stop in a fresh feed still applies.
    // The per-trip age limit is for time predictions, not persistent service status.
    if (u.timestamp && now - u.timestamp > 300) return row;
    // Never propagate a delay through explicit NO_DATA stop updates.
    const dep = !relIs(a?.relationship, 2, 'NO_DATA') ? eventTime(a?.departure, row.scheduledDeparture) : null;
    const arr = !relIs(b?.relationship, 2, 'NO_DATA') ? eventTime(b?.arrival, row.scheduledArrival) : null;
    if (dep === null) return row;
    const arrival = arr !== null && arr >= dep ? arr : dep + row.ride;
    return { ...row, departure: dep, departureLatest: dep, arrival, arrivalLatest: arrival,
      quality: 'live', departureApprox: true, arrivalApprox: arr === null,
      liveArrival: arr !== null, fetchedAt: provider.fetchedAt,
      delay: dep - row.scheduledDeparture, ride: arrival - dep,
      detail: arr === null ? 'Live departure. Arrival estimated using the scheduled ride time.' : 'Live departure and arrival estimates from De Lijn.' };
  }
  function normalizeName(s) { return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
  function applySTIB(rows, provider, now) {
    if (!fresh(provider, now)) return rows;
    const others = rows.filter(r => r.operator !== 'stib');
    const groups = new Map();
    for (const row of rows.filter(r => r.operator === 'stib')) {
      const key = `${row.origin.id}|${row.line}|${row.destination.id}|${normalizeName(row.headsign)}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(row);
    }
    for (const group of groups.values()) {
      const sample = group[0];
      const predictions = (provider.records || []).filter(p => p.stop === sample.origin.id && p.line === sample.line &&
        Object.values(p.destination || {}).some(s => normalizeName(s) === normalizeName(sample.headsign)) && p.time >= now - 30)
        .sort((a, b) => a.time - b.time);
      if (!predictions.length) { others.push(...group); continue; }
      const generated = [];
      for (let i = 0; i < predictions.length; i++) {
        const p = predictions[i];
        const template = group.reduce((a, b) => Math.abs(a.scheduledDeparture - p.time) < Math.abs(b.scheduledDeparture - p.time) ? a : b);
        if (Math.abs(template.scheduledDeparture - p.time) > 3600) continue;
        generated.push({ ...template, id: `live-stib-${sample.origin.id}-${sample.destination.id}-${sample.line}-${p.time}`,
          tripId: null, departure: p.time, departureLatest: p.time, arrival: p.time + template.ride,
          arrivalLatest: p.time + template.ride, quality: 'live', departureApprox: true, arrivalApprox: true,
          scheduledDeparture: null, scheduledArrival: null, delay: null, fetchedAt: provider.fetchedAt,
          detail: 'STIB live waiting-time estimate. This feed has no trip ID: ride time is taken from a nearby matching scheduled service; arrival is an estimate. No delay is inferred.', message: p.message });
      }
      if (!generated.length) { others.push(...group); continue; }
      const last = Math.max(...generated.map(r => r.departure));
      // The feed supplies the next two vehicles. Replace the covered schedule window,
      // rather than showing a predicted bus and its scheduled counterpart twice.
      others.push(...group.filter(r => r.scheduledDeparture > last + 30), ...generated);
    }
    return others;
  }
  function busRows(timetable, reference, direction, horizon = 120, live = null, now = reference) {
    const end = reference + horizon * 60;
    const firstDay = shiftDate(dateISO(reference), -1);
    const lastDay = shiftDate(dateISO(end), 1);
    let rows = [];
    for (const [op, data] of Object.entries(timetable.operators)) {
      for (let iso = firstDay; iso <= lastDay; iso = shiftDate(iso, 1)) {
        if (dateKey(iso) < data.feedStart || dateKey(iso) > data.feedEnd) continue;
        const active = activeServices(data, iso);
        const base = serviceBase(iso);
        for (const [tid, from, to, dep, arr, fromSeq, toSeq] of data.legs) {
          const [rid, service, headsign] = data.trips[tid];
          if (!active.has(service)) continue;
          const a = data.stops[from], b = data.stops[to];
          if ((direction === 'toBN') !== (b.group === 'bn')) continue;
          const departure = base + dep, arrival = base + arr;
          if (departure < reference - 7200 || departure > end + 3600) continue;
          const row = { id: `${op}-${iso}-${tid}-${from}-${to}`, operator: op, tripId: tid,
            serviceDate: iso, line: data.routes[rid].line, routeId: rid, headsign,
            origin: { id: from, ...a }, destination: { id: to, ...b },
            originSequence: fromSeq, destinationSequence: toSeq,
            departure, departureLatest: departure, arrival, arrivalLatest: arrival,
            scheduledDeparture: departure, scheduledArrival: arrival,
            ride: arrival - departure, quality: 'scheduled', arrivalApprox: false,
            detail: 'Published GTFS timetable. No live prediction has been applied to this departure.' };
          rows.push(op === 'delijn' && live ? applyDeLijn(row, live.providers?.delijn, now) : row);
        }
      }
    }
    if (live) rows = applySTIB(rows, live.providers?.stib, now);
    return rows.filter(r => r.departure >= reference && r.departure <= end);
  }
  function easter(y) {
    const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4;
    const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3);
    const h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4;
    const l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
    const month = Math.floor((h + l - 7 * m + 114) / 31), day = (h + l - 7 * m + 114) % 31 + 1;
    return `${y}-${pad(month)}-${pad(day)}`;
  }
  function holiday(iso) {
    const y = +iso.slice(0, 4), suffix = iso.slice(5), e = easter(y);
    return ['01-01', '05-01', '07-21', '08-15', '11-01', '11-11', '12-25'].includes(suffix) ||
      [1, 39, 50].some(n => shiftDate(e, n) === iso);
  }
  const MORNING = ['05:30', '05:40', '05:50', '06:00', '06:10', '06:20', '06:30', '06:40', '06:50', '07:00',
    '09:35', '09:45', '09:55', '10:05', '10:20', '10:35', '10:50', '11:05', '11:20', '11:30', '11:40', '11:50'];
  const AFTERNOON = ['14:05', '14:15', '14:30', '14:45', '15:00', '15:10', '15:20', '15:30', '15:37', '15:44', '15:53', '15:58',
    '18:40', '18:50', '19:05', '19:15', '19:30', '19:45', '20:00', '20:20', '20:40', '21:00', '21:20', '21:40'];
  // User-approved assumption: an anchored eight-minute grid, clipped to the
  // PDF's peak windows. Do not reset the grid at each clock hour.
  function peakTimes(start, finish) {
    const minutes = t => t.split(':').map(Number).reduce((h, m) => h * 60 + m);
    const times = [];
    for (let t = minutes(start); t <= minutes(finish); t += 8) times.push(`${pad(Math.floor(t / 60))}:${pad(t % 60)}`);
    return times;
  }
  const MORNING_PEAK = peakTimes('07:00', '09:30');
  const AFTERNOON_PEAK = peakTimes('16:00', '18:30');
  // First lunchtime row confirmed by the user as TNT departures.
  const LUNCH = ['12:05', '12:20', '12:35', '12:50', '13:05', '13:20', '13:35', '13:50'];
  // Preserve the two supplied estimates exactly. They imply different offsets,
  // so later Rogier times are deliberately left unspecified.
  const ROGIER_ESTIMATES = { '12:05': '12:16', '12:20': '12:32' };
  function shuttleRows(reference, direction, horizon = 120) {
    const end = reference + horizon * 60, result = [], seen = new Set();
    for (let iso = dateISO(reference); iso <= dateISO(end); iso = shiftDate(iso, 1)) {
      if (iso.slice(0, 4) !== '2026' || [0, 6].includes(dow(iso)) || holiday(iso)) continue;
      const reverse = direction === 'toBN';
      const origin = { id: reverse ? 'tnt-shuttle' : 'bn-shuttle', group: reverse ? 'shuttle' : 'bn', name: reverse ? 'Tour & Taxis shuttle' : 'Brussels North shuttle', code: 'T&T' };
      const destination = { id: reverse ? 'bn-shuttle' : 'tnt-shuttle', group: reverse ? 'bn' : 'shuttle', name: reverse ? 'Brussels North shuttle' : 'Tour & Taxis shuttle', code: 'T&T' };
      function fixed(clock, shift = 0, { assumedPeak = false, lunch = false } = {}) {
        const baseDeparture = wallEpoch(iso, clock);
        const departure = baseDeparture + shift * 60;
        const id = `shuttle-${iso}-${departure}`;
        if (departure < reference || departure > end || seen.has(id)) return;
        seen.add(id);
        const quality = assumedPeak ? 'assumed' : lunch ? 'confirmed' : shift ? 'derived' : 'scheduled';
        let detail;
        if (assumedPeak) {
          detail = 'Exact departure generated from your assumed eight-minute peak grid, not an exact time published in the PDF and not live-tracked. ' +
            (shift ? 'The morning grid starts at 07:00 from BN; TNT departures use that grid plus 8 minutes. ' :
              reverse ? 'The afternoon TNT grid starts at 16:00. ' : 'The morning BN grid starts at 07:00. ') +
            'Arrival adds your 8-minute ride estimate. Traffic or irregular operation can change both times.';
        } else if (lunch) {
          detail = 'You confirmed that the lunchtime row starts at TNT. This is a TNT departure, with BN arrival assumed 8 minutes later. ' +
            'The shuttle continues towards Rogier; the BN arrival is not a BN-to-TNT departure. Not live-tracked.';
        } else if (shift) {
          detail = 'Morning TNT departure = listed BN departure + 8 minutes, using your return-trip rule. Not live-tracked. Ride time: 8 minutes, supplied by you.';
        } else {
          detail = 'Departure transcribed from the 2026 shuttle PDF. The 8-minute ride is supplied by you; arrival is approximate. Staff-only service.';
        }
        result.push({ id, operator: 'shuttle', line: 'T&T', origin, destination,
          headsign: lunch ? 'Rogier (via Brussels North)' : reverse ? 'Brussels North' : 'Tour & Taxis',
          serviceDate: iso, departure, departureLatest: departure,
          arrival: departure + 480, arrivalLatest: departure + 480,
          ride: 480, baseDeparture, publishedDeparture: assumedPeak ? null : baseDeparture,
          quality, assumedPeak, lunch, returnOffset: shift,
          rogierArrival: lunch && ROGIER_ESTIMATES[clock] ? wallEpoch(iso, ROGIER_ESTIMATES[clock]) : null,
          arrivalApprox: true, staffOnly: true, detail });
      }
      // Add published points first so 07:00 (and its 07:08 TNT return) does not
      // appear twice where the PDF's fixed list overlaps the assumed peak grid.
      MORNING.forEach(t => fixed(t, reverse ? 8 : 0));
      MORNING_PEAK.forEach(t => fixed(t, reverse ? 8 : 0, { assumedPeak: true }));
      if (reverse) {
        LUNCH.forEach(t => fixed(t, 0, { lunch: true }));
        AFTERNOON.forEach(t => fixed(t));
        AFTERNOON_PEAK.forEach(t => fixed(t, 0, { assumedPeak: true }));
      }
      // Still exclude the disputed 22:00 entry and unconfirmed reverse trips.
      // Lunch BN/Rogier waypoints are arrivals, not reverse departures.
    }
    return result.sort((a, b) => a.departure - b.departure);
  }
  function shuttleStatus(reference, direction) {
    const iso = dateISO(reference), t = hhmm(reference);
    if (iso.slice(0, 4) !== '2026') return { title: '2026 timetable only', note: 'No confirmed shuttle timetable for this year.', kind: 'warning' };
    if ([0, 6].includes(dow(iso))) return { title: 'Weekdays only', note: 'The staff shuttle is not listed for weekends.', kind: 'closed' };
    if (holiday(iso)) return { title: 'Holiday service unconfirmed', note: 'Public-holiday operation is not specified in the PDF.', kind: 'warning' };
    if (direction === 'toTNT' && t >= '12:00') return { title: 'Return times unconfirmed', note: 'Afternoon BN → TNT departures remain unspecified. Lunchtime BN times are arrivals on the way to Rogier, not returns to TNT.', kind: 'warning' };
    if (direction === 'toBN' && t >= '12:00' && t < '14:05') return { title: 'Lunch departs from TNT', note: 'TNT departures confirmed by you; BN arrival assumed 8 minutes later.', kind: 'confirmed' };
    if (direction === 'toBN' && t > '21:40') return { title: 'Finished for today', note: '21:40 is the stated last TNT departure; the disputed 22:00 row is excluded.', kind: 'closed' };
    return { title: 'Staff shuttle', note: '8-minute ride · timetable + your peak-grid assumption, not live-tracked.', kind: 'scheduled' };
  }
  function walkingEnabled(settings) {
    return Boolean(settings.includeWalking && settings.walking?.profiles &&
      (settings.direction || 'toBN') === 'toBN');
  }
  function applyWalking(rows, settings) {
    const active = walkingEnabled(settings), profiles = settings.walking?.profiles || {};
    const reference = settings.reference;
    const result = [];
    for (const original of rows) {
      const row = { ...original };
      // Keep actual bus platforms untouched. Only the previously unspecified
      // TNT shuttle point is enriched with the user's exact pickup pin.
      const shuttlePin = profiles.shuttle;
      if (row.operator === 'shuttle' && shuttlePin) {
        for (const endpoint of ['origin', 'destination']) {
          if (row[endpoint].id === 'tnt-shuttle') row[endpoint] = {
            ...row[endpoint], lat: shuttlePin.lat, lon: shuttlePin.lon, locationSource: 'User-provided shuttle pin'
          };
        }
      }
      const profile = profiles[row.origin.group];
      const known = Number.isFinite(profile?.minutes) && profile.minutes >= 0;
      // A missing walk must never be silently treated as zero when leaving home.
      if (active && !known) continue;
      const walkMinutes = active ? profile.minutes : 0;
      const walkSeconds = walkMinutes * 60;
      const readyAt = reference + walkSeconds;
      // Apply this after real-time updates: delays can change which bus is reachable.
      // No extra boarding buffer is added. Equality is allowed by the model.
      if (active && row.departure < readyAt) continue;
      row.walkingActive = active;
      row.walkMinutes = walkMinutes;
      row.walkSeconds = walkSeconds;
      row.walkReadyAt = readyAt;
      row.leaveHomeBy = active ? row.departure - walkSeconds : null;
      row.waitAfterWalk = Math.max(0, row.departure - readyAt);
      row.walkReference = active ? { ...profile } : null;
      row.totalJourneySeconds = row.arrival - reference;
      // The bus arrival is already an absolute timestamp. Adding the pre-boarding
      // walk to it would count that walk twice. Return trips stay stop-to-stop.
      result.push(row);
    }
    return result;
  }
  function allRows(timetable, settings, live = null, now = Date.now() / 1000) {
    const { reference, direction = 'toBN', horizon = 120, includeShuttle = true, mode = 'now' } = settings;
    const list = busRows(timetable, reference, direction, horizon, mode === 'now' ? live : null, now);
    if (includeShuttle) list.push(...shuttleRows(reference, direction, horizon));
    return settings.walking ? applyWalking(list, settings) : list;
  }
  function filterRows(rows, { operator = 'all', stop = 'all', sort = 'arrival' } = {}) {
    return rows.filter(r => (operator === 'all' || r.operator === operator) &&
      (stop === 'all' || r.origin.group === stop || r.destination.group === stop))
      .sort((a, b) => (a.cancelled ? 1 : 0) - (b.cancelled ? 1 : 0) ||
        (sort === 'departure' ? a.departure - b.departure : a.arrivalLatest - b.arrivalLatest) ||
        a.departure - b.departure || a.line.localeCompare(b.line, 'en', { numeric: true }));
  }
  const api = { ZONE, parts, dateISO, hhmm, wallEpoch, serviceBase, shiftDate, dateKey, dateFromKey,
    dow, activeServices, fresh, eventTime, busRows, shuttleRows, shuttleStatus, allRows, filterRows, walkingEnabled, applyWalking,
    holiday, easter, MORNING, AFTERNOON, MORNING_PEAK, AFTERNOON_PEAK, LUNCH, ROGIER_ESTIMATES, peakTimes, applyDeLijn, applySTIB };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CommuteEngine = api;
})(typeof window !== 'undefined' ? window : globalThis);
