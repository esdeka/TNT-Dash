# Northbound — Tour & Taxis ↔ Brussels North

A personal, responsive commute dashboard for the Parkdreef neighbourhood: home-to-BN with your walking estimates, and stop-to-stop in the return direction.

## Open it

- **Live dashboard:** use the running Northbound preview in this workspace.
- **Offline / downloadable dashboard:** open `Dashboard.html`. It contains the full filtered timetable, styles, font, code and original shuttle PDF. No network connection is needed for planning. It never presents offline data as live.
- **Run the live version yourself:** Python 3.10 or newer is recommended.

```bash
cd commute
python -m pip install -r requirements.txt
python server.py --port 3000
```

Open `http://localhost:3000` in a browser on that computer. In a hosted preview, use its HTTPS URL instead. Browser API calls use relative URLs, and the server binds to `0.0.0.0` so proxy previews work.

No API key is needed for the public feeds used here. The only optional Python dependency is a fallback parser for binary GTFS-RT; the portal currently supplies JSON.

## What it does

- Defaults to **TNT → BN**; reverse the direction with the swap button.
- **Leave now** uses current operator predictions where supplied, with scheduled fallbacks.
- **Plan a trip** uses the chosen Brussels date/time and the actual GTFS service calendar. It does not apply today's live delays to another time.
- Compares **T&T staff shuttle, MIVB/STIB and De Lijn**.
- Filters **Suzan Daniel, Picard and the shuttle**, as well as individual operators.
- Recommends the earliest **listed** arrival, not just the first departure. Peak shuttle departures use the user-approved, anchored 8-minute grid. Each is ranked by wait to that departure + the 8-minute ride.
- Includes exact bus stop IDs, vehicle destinations, source details, cancellation handling, date coverage and a schematic neighbourhood overview.
- Stores only direction, “include staff shuttle” and “Start from home” preferences locally. No location tracking or analytics.

## Walking from home — latest user preferences

Walking is now included by default **only when leaving home towards BN**. You explicitly asked not to add the walk back home on BN → TNT journeys.

| Walking reference | Minutes | Latitude | Longitude |
|---|---:|---|---|
| Brussel Picard | 5 | 50.86404643162095 | 4.343968608510816 |
| TNT shuttle stop | 5 | 50.86394437949276 | 4.346459999157837 |
| Suzan Daniel on Picard street | 8 | 50.863076897694725 | 4.346976807605478 |

You confirmed that **8 minutes applies to all nearby Suzan Daniel platforms**, including De Lijn. This is an area walking estimate based on your reference pin. Bus boarding coordinates remain the actual operator GTFS stop coordinates; they are not all replaced with the reference pin. The user-supplied TNT coordinate now provides the shuttle pickup location.

- **Start from home** is on by default for TNT → BN. Turn it off if you are already at a stop.
- The selected time is the earliest time you can leave home. A bus is reachable only if its departure is at or after that time plus the walk.
- **Leave home by** = bus departure − walk. This is shown on the recommendation, operator cards, departure rows and trip details.
- Total time is **walk + wait after walking + ride**. It equals the absolute BN arrival minus the selected home departure time. The pre-boarding walk is never added to that arrival timestamp a second time.
- Fresh live predictions are applied **before** the walking check; a delay can make a previously unreachable departure reachable.
- There is **no extra boarding buffer**. Arriving exactly at the modeled departure is allowed; walk and bus times remain estimates, so allow a safety margin yourself.
- **BN → TNT remains stop-to-stop**, without a walk back home. Train-platform access is excluded in both directions.

The exact pins, scope and time-calculation explanation are in **Walks & pins → Your walks**. Settings are stored separately in `data/walking.json`, so refreshing GTFS schedules does not overwrite them.

Example: a home departure of 08:00, 5-minute walk, bus at 08:06 and BN arrival at 08:12 gives 5 min walking + 1 min waiting + 6 min riding = **12 minutes**, not 17. The latest time to leave home for that bus is **08:01**.

A row is a **boarding option**, not a unique vehicle: the same bus can be shown at both Picard and Suzan Daniel. In the return direction it can be shown for two different drop-off stops.

## Shuttle: careful interpretation of the uploaded 2026 PDF

- Ride time is the user's **8-minute assumption**.
- Listed morning times are **BN → TNT**. Morning TNT returns apply the user's **+8-minute rule**: 05:30 → 05:38, 05:40 → 05:48, etc. These are labelled **Derived +8 min**, not live.
- The user now explicitly requests **assumed departures every 8 minutes** inside the continuous-service windows. These are labelled **Assumed 8-min grid**, not exact operator-published times and not live.
  - Morning **BN → TNT**: 07:00, 07:08, 07:16, …, 07:56, 08:04, …, **09:24**. The grid is anchored at 07:00, not reset each hour. The next published BN departure is 09:35.
  - Morning **TNT → BN**: shift that grid by +8 minutes: **07:08, 07:16, …, 09:32**. The next derived TNT departure is 09:43.
  - Afternoon **TNT → BN**: **16:00, 16:08, 16:16, …, 18:24**, within the published 16:00–18:30 window. The next listed TNT departure is 18:40.
  - Where the fixed PDF list overlaps the peak grid (BN 07:00 / TNT 07:08), only one row is shown; the published/derived source takes precedence.
- The user has **resolved the lunchtime direction**: the first row starts at **TNT**. All eight TNT departures are now included and labelled **User-confirmed**: 12:05, 12:20, 12:35, 12:50, 13:05, 13:20, 13:35, 13:50. BN arrival is assumed **+8 minutes** (12:13, 12:28, …, 13:58).
- The route continues **TNT → BN → Rogier**. The user supplied Rogier arrival estimates **12:16** for the 12:05 TNT trip and **12:32** for the 12:20 trip. Both are retained exactly; they imply different offsets, so later Rogier times remain unspecified. These estimates appear in the timetable and lunch-trip details. Rogier is continuation information only and is not a new comparison destination. **BN lunch arrivals are not reverse departures to TNT.** The original PDF is unchanged.
- The prose says last TNT departure 21:40 and last BN departure 22:00, but the TNT→BN table also lists 22:00. The disputed **22:00 entry is excluded** in both directions; TNT 21:40 is retained.
- Afternoon **BN → TNT** reverse times are not clearly published; no automatic afternoon +8-minute rule is applied.
- The official visiting page lists weekday operation. Weekend shuttle trips are not shown. Belgian public-holiday operation is unconfirmed and not ranked.
- The PDF is for **2026**, not an indefinitely repeating schedule.
- The uploaded PDF restricts the shuttle to **employees**. Residence on the site alone does not establish eligibility. Use the “Include staff shuttle” switch accordingly.

The original file is embedded in the downloadable HTML and also available at `/shuttle.pdf` on the live server.

## Data sources and freshness

Initial feeds were downloaded on **4 September 2026**:

| Operator | Saved GTFS coverage | Direct routes in the extracted feed |
|---|---|---|
| MIVB / STIB | 31 August–27 September 2026 | 14, 20 |
| De Lijn | 3 September–12 November 2026 | 714, R14, R15, R30, R31, R40, R41, R45, R50, R60, X60 |

Not every listed route operates at every stop, in both directions, or on every date. The timetable engine filters the exact ordered stop pairs, calendar exceptions, pickup/drop-off permissions, and post-midnight service days. It does **not** repeat the saved timetable outside its coverage.

Official public data catalogue: https://data.belgianmobility.io/en/data.html

Live endpoints:

- STIB waiting times: `https://api-management-discovery-production.azure-api.net/api/datasets/stibmivb/rt/WaitingTimes`
- De Lijn trip updates: `https://api-management-discovery-production.azure-api.net/api/gtfs/feed/delijn/rt/trip-update`

**STIB:** The next two expected stop arrivals have no trip IDs. The destination is checked, and ride time is taken from a nearby matching scheduled trip. The other-end arrival is an estimate. No matched-trip delay is invented. End-of-service sentinel rows are not departures.

**De Lijn:** Updates are joined by exact trip ID and service date. Explicit departure predictions, trip cancellations, and skipped endpoints are handled. NO_DATA updates do not become live predictions. Persistent cancellation flags in a fresh feed remain valid even when the trip was last modified earlier.

**Freshness:** live predictions expire after 120 seconds. De Lijn's feed timestamp is checked too. STIB does not expose a feed-generation timestamp at this endpoint, so its age is measured from retrieval. After expiration or any network error, the app returns to scheduled times and labels them accordingly.

**Refresh policy:** a feed check happens when the server-backed dashboard opens or switches to Leave now. Further refreshes are user-initiated. There is no continuous background polling. Upstream requests within 60 seconds share a cache. The UI clock and countdowns update independently of the feed.

**Quota:** BMC's public tier is 100 requests/day, 10/minute. This app caps live usage at 80 upstream requests per rolling 24h, 4/minute, leaving headroom for schedule downloads and source checks. Each two-operator refresh uses two calls. Quota state persists in `data/quota.json`.

**Not a comprehensive disruption monitor.** No complete service-alert feed is connected. Check operator notices for works, strikes or diversions before important trips.

## Refresh the timetables

```bash
python refresh_schedules.py
python build.py
# Stop the old server (Ctrl+C), then restart:
python server.py --port 3000
```

This uses **two public API requests** and downloads the operators' full GTFS ZIPs. De Lijn's ZIP was approximately 217 MB; allow sufficient disk space. Archives are kept under `../.cache/transit/`, while only the ~4 MB corridor-specific subset is retained in `data/timetable.json` and in the deliverable. Downloads are manual, not automatic. Respect the public quota when running repeated imports.

To rebuild from existing downloaded ZIPs:

```bash
python refresh_schedules.py --cached
python build.py
```

A restart is required because the server loads its route filter at startup. Reopen or refresh the browser after a rebuild.

## Files

- `Dashboard.html` — self-contained, scheduled-only downloadable dashboard.
- `server.py` — live-feed proxy, shared cache, quota limits and server.
- `refresh_schedules.py` — official GTFS importer and direct-connection filter.
- `build.py` — embeds all assets, schedule data and PDF into the HTML.
- `static/engine.js` — pure time, calendar, routing and prediction engine.
- `static/app.js` — user interface and source disclosures.
- `static/template.html`, `style.css`, `readability.css` — layout and responsive design.
- `static/shuttle.pdf` — original uploaded timetable.
- `static/manrope-latin.woff2`, `FONT-LICENSE.txt` — embedded font and licence.
- `data/timetable.json` — compact, attributed operator dataset.
- `data/walking.json` — your exact walking-reference pins, 5/5/8-minute walks and outbound-only scope. Separate from GTFS, retained across schedule refreshes.
- `test_engine.js`, `test_ui.js` — regression tests.

## Tests

Core logic, with Node.js 20+:

```bash
node test_engine.js
```

The engine tests cover walking reachability, exact boarding cut-offs, latest home departure, no double-counting, outbound-only scope, individual platform coordinates, timezone conversion, first morning shuttle returns, anchored eight-minute peak grids, boundary clipping, duplicate removal, the confirmed lunch row and Rogier estimates, direction changes, unresolved late/reverse periods, weekends/holidays, route filtering, GTFS date exceptions, post-midnight services, data expiry, cancellation enums, NO_DATA, prediction provenance, and sorting.

Optional browser tests, with a running dashboard:

```bash
npm install --no-save playwright
npx playwright install --with-deps chromium
node test_ui.js
```

The browser suite checks the controls, filters, pagination, modal tabs, error fallback, 320–1440 px layouts, downloadable file, and an opaque-origin `sandbox="allow-scripts"` iframe similar to the workspace viewer.

## Attribution and licences

Source: **STIB-MIVB – Open Data – 4 September 2026**.
Source: **De Lijn – Open Data – 4 September 2026**.
Contains data originally published by these operators, filtered and adapted for the Northbound personal dashboard.

Operator data: **CC BY 4.0** — https://creativecommons.org/licenses/by/4.0/
Platform terms: https://data.belgianmobility.io/en/terms.html

Shuttle assumptions: user-requested 8-minute peak grid, +8-minute morning returns / BN ride estimate, lunchtime TNT direction confirmed by the user, and the two Rogier arrival estimates. Walking references and 5/5/8-minute times are user-supplied; they apply only from home towards BN, with 8 minutes for all nearby Suzan Daniel platforms as explicitly approved.

Shuttle source: the user's uploaded `TT-SHUTTLE-SCHEDULE.pdf`, also published at https://tour-taxis.com/wp-content/uploads/2026/01/TT-SHUTTLE-SCHEDULE.pdf
Weekday reference: https://tour-taxis.com/your-visit/

The PDF remains the property of its publisher. Manrope is distributed under the SIL Open Font License 1.1 (included). The map is an original schematic, not external map tiles and not a navigation aid.
